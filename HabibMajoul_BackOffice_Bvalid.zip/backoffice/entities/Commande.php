<?php
	class Commande{
		private $id;
		private $idClient;
		private $etat;
		private $datePlace;
		function __construct($idClient, $etat, $datePlace){
			$this->idClient = $idClient;
			$this->etat = $etat;
			$this->datePlace = $datePlace;
		}
		function getId(){
			return $this->id;
		}
		function getIdClient(){
			return $this->idClient;
		}
		function getEtat(){
			return $this->etat;
		}
		function getDatePlace(){
			return $this->datePlace;
		}
	}
?>
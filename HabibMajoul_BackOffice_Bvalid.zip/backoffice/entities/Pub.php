<?php
	class Pub{
		private $ref;
		private $idsponsor;
		private $images;
		private $titre;
		private $description;

		function __construct($ref, $idsponsor, $images, $titre, $description){
			$this->ref = $ref;
			$this->idsponsor = $idsponsor;
			$this->images = $images;
			$this->titre= $titre;
			$this->description = $description;

		}
		function getRef(){
			return $this->ref;
		}
		function getIdsponsor(){
			return $this->idsponsor;
		}
		function getImage(){
			return $this->images;
		}
		function getTitre(){
			return $this->titre;
		}

		function getDesc(){
			return $this->description;
		}


		function setRef($ref){
			$this->ref = $ref;
		}
		function setIdsponsor($idsponsor){
			$this->idsponsor= $idsponsor;
		}
		function setImage($images){
			$this->images = $images;
		}
		function setTitre($titre){
			$this->titre = $titre;
		}

		function setDesc($description){
			$this->description = $description;
		}

	}
?>

<?php
	class ProduitCommande{
		private $refProd;
		private $idCommande;
		private $qte;
		function __construct($refProd, $idCommande, $qte){
			$this->refProd = $refProd;
			$this->idCommande = $idCommande;
			$this->qte = $qte;
		}
		function getRefProd(){
			return $this->refProd;
		}
		function getIdCommande(){
			return $this->idCommande;
		}
		function getQte(){
			return $this->qte;
		}
		function setRefProd($refProd){
			$this->refProd = $refProd;
		}
		function setIdCommande($idCommande){
			$this->idCommande = $idCommande;
		}
		function setQte($qte){
			$this->qte = $qte;
		}
	}
?>
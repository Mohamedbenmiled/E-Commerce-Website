

function verif(){
  var valid = true;

  var letters = /^[a-zA-Z]+[a-zA-Z]+$/;

  var maile =/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

  var mail = document.getElementById("mail").value;
  if (maile.test(mail)==false) {
    document.getElementById("mail").value = '';
    document.getElementById("mail").focus();
    document.getElementById("mail").placeholder = "EMAIL Invalide";
    valid = false;
  }
  var id = document.getElementById("id").value;
  if(id == ""){
    document.getElementById("id").value = '';
    document.getElementById("id").focus();
    document.getElementById("id").placeholder = "ID Invalide";
    valid = false;
  }



  var nom = document.getElementById("nom").value;
  if(letters.test(nom) == false){
    document.getElementById("nom").value = '';
    document.getElementById("nom").focus();
    document.getElementById("nom").placeholder = "NOM Invalide";
    valid = false;
  }
  var prenom = document.getElementById("prenom").value;
  if(letters.test(prenom) == false){
    document.getElementById("prenom").value = '';
    document.getElementById("prenom").focus();
    document.getElementById("prenom").placeholder = "PRENOM Invalide";
    valid = false;
  }
  var adresse = document.getElementById("adresse").value;
  if(adresse == ""){
    document.getElementById("adresse").value = '';
    document.getElementById("adresse").focus();
    document.getElementById("adresse").placeholder = "ADRESSE Invalide";
    valid = false;
  }
  /*if(document.getElementById("agreeTerms").checked == false)
  {
    alert("Must Agree To Terms");
    valid=false;
  }*/





  if(!valid){
    return false;
  }

  document.getElementById("form").submit();
  return true;
}

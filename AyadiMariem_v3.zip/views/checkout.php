<!DOCTYPE html>
<html>
	<head>
		<title>Veni Vidi</title>
		<link rel="stylesheet" type="text/css" href="../stylesheet.css">
	</head>

	<body>
		<?php 
			$idClient = $_POST['idClient'];
			$idPanier = $_POST['idPanier'];
		?>
		<div class="topBar">
			<table style="width: 95%; height: 100%">
				<tr>
					<td style="width: 71%; padding-left: 5%">
						<a class="venividi" href="index.php">Veni Vidi</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="index.php">Home</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="about.php">About</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="contact.php">Contact</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="products.php">Shop</a>
					</td>
					<td style="width: 6%">
						<a class="choix" href="cart.php">
							<img src="../images/cart.png" alt="Cart" class="cart">
							<?php 
								include "../config.php";
								include "../entities/ProduitCommande.php";
								include "../core/ProduitCommandeC.php";
								$produitCommande1C = new ProduitCommandeC();
								$idClient = 1;
								$nb = $produitCommande1C->getNbCart($idClient);
							?>
							<label class="cartNb"><?php echo $nb;?></label>
						</a>
					</td>
				</tr>		
			</table>	
		</div>
		<div class="cartDiv" align="center">	
			<div class="cartTitleBox" align="left">
				<label class="cartTitle">CHECKOUT</label>
			</div>
		</div>
		<form method="POST" action="crud/ajoutLivraison.php">
			<input type="submit" value="PLACE ORDER" style="background-color: rgb(3, 102, 214);
	margin-right: 200px;
	margin-top: 100px;
	float: right;
	height: 34px;
	width: 110px;
	color: white;
	font-weight: bold;
	font-size: 12px;
	border: 1px solid rgb(3, 102, 214);
	border-radius: 3px;
	cursor: pointer;">
		<input type="hidden" value="<?php echo $_POST['idClient'];?>" name="idClient">
		<input type="hidden" value="<?php echo $_POST['idPanier'];?>" name="idCommande">
		</form>	
		<div class="prdBottomImg" style="margin-top: 296px;">
		</div>
	</body>
</html>
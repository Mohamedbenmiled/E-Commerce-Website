<!DOCTYPE html>
<html>
	<head>
		<title>Veni Vidi</title>
		<link rel="stylesheet" type="text/css" href="../stylesheet.css">
	</head>

	<body>
		<div class="topBar">
			<table style="width: 95%; height: 100%">
				<tr>
					<td style="width: 71%; padding-left: 5%">
						<a class="venividi" href="index.php">Veni Vidi</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="index.php">Home</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="about.php">About</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="contact.php">Contact</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="products.php">Shop</a>
					</td>
					<td style="width: 6%">
						<a class="choix" href="cart.php">
							<img src="../images/cart.png" alt="Cart" class="cart">
							<?php 
								include "../config.php";
								include "../entities/ProduitCommande.php";
								include "../core/ProduitCommandeC.php";
								$produitCommande1C = new ProduitCommandeC();
								$idClient = 1;
								$nb = $produitCommande1C->getNbCart($idClient);
							?>
							<label class="cartNb"><?php echo $nb;?></label>
						</a>
					</td>
				</tr>		
			</table>	
		</div>
		<div class="first" align="center">
			<label class="hugeTitle">VENI VIDI</label><br><br><br><br><br><br><br><br><br><br>
			<input type="button" value="VIEW COLLECTION" onclick="location.href='products.php';" class="collection">
		</div>
		<div class="second" align="center">
			<label class="s1">WE ARE VENI VIDI</label>
			<p class="s2">Elegance isn't solely defined by what you wear. It's how you carry yourself.</p>
			<table align="center" class="tableB">
				<tr>
					<td>
						<img src="../images/box.png" alt="beautiful products" class="icon1">
					</td>
					<td>
						<img src="../images/delivery.png" alt="fast delivery" class="icon2">
					</td>
					<td>
						<img src="../images/satisfaction.png" alt="100% satisfaction" class="icon3">
					</td>
				</tr>	
				<tr>
					<td>
						<p class="subImageIndex">Beautiful Products</p>
					</td>
					<td>
						<p class="subImageIndex">Fast Delivery</p>
					</td>
					<td>
						<p class="subImageIndex">100% Satisfaction</p>
					</td>
				</tr>
				<tr>
					<td>
						<p class="subImageIndexT">I never look at other people's work. My mind has to be completely focused on my own illusions. It's a philosophy of life. A practice with no end.</p>
					</td>
					<td>
						<p class="subImageIndexT">If you do this, something will change, what will change is that you will change, your life will change, and if you can change you, you can perhaps change the world.</p>
					</td>
					<td>
						<p class="subImageIndexT">I've always thought of the accessories as the Alpha and Omega of the fashion alphabet. I like the things around me to be beautiful and slightly dreamy.</p>
					</td>
				</tr>
			</table>
		</div>
		<div class="third" align="center">
			<p class="slogan">BE INSPIRED. GET AHEAD OF TRENDS.</p>
		</div>
		<div class="fourth">
		</div>
		<div class="preFooter">
		</div>
		<div class="footer">
		</div>
		<?php 
			include("../entities/Event.php");
			include("../core/EventC.php");
			$eventC = new EventC();
			$date = date("Y/m/d H:i:s");
			$eventActuel = $eventC->recupererEventByDate($date);
			if($eventActuel->rowCount() != 0){
				foreach($eventActuel as $rowEvent){
				?> 
					<input type="hidden" id="theme" value="../images/themes/<?php echo $rowEvent['nom']?>.png">
					<div class="theme" id="divTheme">
					</div>
					<script type="text/javascript">
						var link = document.getElementById("theme").value;
						document.getElementById("divTheme").style.backgroundImage = "url('" + link + "')";
					</script>
				<?php
				}
			}
		?>
	</body>
</html>
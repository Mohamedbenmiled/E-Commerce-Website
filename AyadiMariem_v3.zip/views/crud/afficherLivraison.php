<?php
    include "../core/LivraisonC.php";
    $livraison1C = new LivraisonC();
    $listeLivraisons = $livraison1C->afficherLivraisons();
?>

<table border="1">
    <tr>
        <td>Id Commande</td>
        <td>Cin Livreur</td>
        <td>Etat</td>
        <td>Date de Livraison</td>
        <td>Supprimer</td>
        <td>Modifier</td>
    </tr>
    <?php
    	foreach($listeLivraisons as $row){
    ?>
    <tr>
        <td><?php echo $row['idCommande']; ?></td>
        <td><?php echo $row['cinLivreur']; ?></td>
        <td><?php echo $row['etat']; ?></td>
        <td><?php echo $row['dateLivraison']; ?></td>
        <td>
        	<form method="POST" action="supprimerLivraison.php">
	            <input type="submit" name="supprimer" value="Supprimer">
	            <input type="hidden" value="<?php echo $row['idCommande']; ?>" name="idCommande">
            </form>
        </td>
        <td>
        	<a href="modifierLivraison.php?idCommande=<?php echo $row['idCommande']; ?>">
            Modifier</a></td>
    </tr>
    <?php
    	}
    ?>
</table>
<?php
	include "../../config.php";
	include "../../entities/ProduitCommande.php";
	include "../../core/ProduitCommandeC.php";
	include "../../entities/Commande.php";
	include "../../core/CommandeC.php";
	include "../../entities/Produit.php";
	include "../../core/ProduitC.php";
	include("../../entities/Event.php");
	include("../../core/EventC.php");
	$eventC = new EventC();
	$date = date("Y/m/d H:i:s");
	$eventActuel = $eventC->recupererEventByDate($date);
	include("../../core/RemiseC.php");
	include("../../entities/Remise.php");
	$remiseC = new RemiseC();
	$produitCommandeC = new ProduitCommandeC();
	$p = $produitCommandeC->recupererProduitCommande($_POST['id']);
	foreach($p as $row){
		$produitC = new ProduitC();
		$produit = $produitC->recupererProduit($row['refProd']);
		foreach($produit as $rowP){
			$commandeC = new CommandeC();
			$com = $commandeC->recupererCommande($row['idPanier']);
			$onSale = false; 
			$tx = 0;
			if($eventActuel->rowCount() != 0){
				$eventActuel = $eventC->recupererEventByDate($date);
				foreach($eventActuel as $rowEvent){
					$remise = $remiseC->recupererRemise($rowP['ref'], $rowEvent['id']);
					if($remise->rowCount() != 0){
						$onSale = true; 
						foreach($remise as $rowRemise){
							$tx = $rowRemise['taux'];
						}	
					}
				}
			}
			foreach($com as $rowC){
				if($onSale){
					$nouvPrix = ((($tx*$rowP['prix'])/100) * $_POST['qte']) + $rowC['prixTotal'] - ((($tx*$rowP['prix'])/100) * $row['qte']);
				}else{
					$nouvPrix = ($rowP['prix'] * $_POST['qte']) + $rowC['prixTotal'] - ($rowP['prix'] * $row['qte']);
				}
				$Commande = new Commande($row['idPanier'], $nouvPrix);
				$commandeC->modifierCommande($Commande, $row['idPanier']);
			}
		}
		$produitCommande = new ProduitCommande($_POST['id'], $row['refProd'], $row['idClient'], $_POST['qte'], $row['idPanier'], $row['date_a']);
		$produitCommandeC->modifierProduitCommande($produitCommande, $_POST['id']);
	}
	header('Location: ../cart.php?success=true');
?>

<?php
	include("../config.php");
	include "../core/LivraisonC.php";
	$livraisonC = new LivraisonC();
	if(isset($_POST["idCommande"])){
		$livraisonC->supprimerLivraison($_POST["idCommande"]);
		header('Location: afficherLivraison.php');
	}
?>
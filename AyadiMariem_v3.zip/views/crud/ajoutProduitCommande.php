<?php
	include "../../config.php";
	include "../../entities/ProduitCommande.php";
	include "../../core/ProduitCommandeC.php";
	include("../../entities/Event.php");
	include("../../core/EventC.php");
	$eventC = new EventC();
	$date = date("Y/m/d H:i:s");
	$eventActuel = $eventC->recupererEventByDate($date);
	include("../../core/RemiseC.php");
	include("../../entities/Remise.php");
	$remiseC = new RemiseC();
	if(isset($_POST['idClient']) and isset($_POST['qte']) and isset($_POST['refProd'])){
		$produitCommande1C = new ProduitCommandeC();
		include "../../entities/Commande.php";
		include "../../core/CommandeC.php";
		$id = $_POST['idClient'].'090'.$_POST['refProd'];
		$commande1C = new CommandeC();
		include "../../entities/Produit.php";
		include "../../core/ProduitC.php";
		$produitC = new ProduitC();
		$result = $produitC->recupererProduit($_POST['refProd']);
		foreach($result as $row){
			$onSale = false; 
			$tx = 0;
			if($eventActuel->rowCount() != 0){
				$eventActuel = $eventC->recupererEventByDate($date);
				foreach($eventActuel as $rowEvent){
					$remise = $remiseC->recupererRemise($row['ref'], $rowEvent['id']);
					if($remise->rowCount() != 0){
						$onSale = true; 
						foreach($remise as $rowRemise){
							$tx = $rowRemise['taux'];
						}	
					}
				}
			}
			$com = $commande1C->recupererCommande($_POST['idClient']);
			if($com->rowCount() == 0){
				if($onSale){
					$commande1 = new Commande($_POST['idClient'], (($tx*$row['prix'])/100) * $_POST['qte']);
				}else{
					$commande1 = new Commande($_POST['idClient'], $row['prix'] * $_POST['qte']);
				}
				$commande1C->ajouterCommande($commande1);
			}else{
				foreach($com as $rowC){
					if($onSale){
						$nouvPrix = ((($tx*$row['prix'])/100) * $_POST['qte']) + $rowC['prixTotal'];
					}else{
						$nouvPrix = ($row['prix'] * $_POST['qte']) + $rowC['prixTotal'];
					}
					$Commande = new Commande($_POST['idClient'], $nouvPrix);
					$commande1C->modifierCommande($Commande, $_POST['idClient']);
				}
			}
		}
		$date = date("Y/m/d H:i:s");
		$quantite = $_POST['qte'];
		$oldPc = $produitCommande1C->recupererProduitCommande($id);
		if($oldPc->rowCount() != 0){
			foreach($oldPc as $rowOldPc){
				$quantite += $rowOldPc['qte'];
			}
		}
		$produitCommande1 = new ProduitCommande($id, $_POST['refProd'], $_POST['idClient'], $quantite, $_POST['idClient'], $date);
		if($oldPc->rowCount() != 0){
			$produitCommande1C->modifierProduitCommande($produitCommande1, $id);
		}else{
			$produitCommande1C->ajouterProduitCommande($produitCommande1);	
		}
		$ref = $_POST['refProd'];
		header("Location: ../item.php?ref=$ref&success=true");
	}else{
		echo "Erreur d'ajout de commande";
		header("Location: ../item.php?ref=$ref&success=false");
	}
?>
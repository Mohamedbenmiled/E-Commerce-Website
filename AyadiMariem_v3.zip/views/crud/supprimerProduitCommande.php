<?php
	include "../../config.php";
	include "../../core/ProduitCommandeC.php";
	include "../../entities/ProduitCommande.php";
	include("../../entities/Event.php");
	include("../../core/EventC.php");
	$eventC = new EventC();
	$date = date("Y/m/d H:i:s");
	$eventActuel = $eventC->recupererEventByDate($date);
	include("../../core/RemiseC.php");
	include("../../entities/Remise.php");
	$remiseC = new RemiseC();
	$produitCommandeC = new ProduitCommandeC();
	if(isset($_POST["id"])){
		$pC = $produitCommandeC->recupererProduitCommande($_POST["id"]);
		$produitCommandeC->supprimerProduitCommande($_POST["id"]);
		include "../../entities/Commande.php";
		include "../../core/CommandeC.php";
		$commande1C = new CommandeC();
		foreach($pC as $rowpC){
			$res = $commande1C->recupererCommande($rowpC['idPanier']);
			foreach($res as $rowRes){
				include "../../entities/Produit.php";
				include "../../core/ProduitC.php";
				$produitC = new ProduitC();
				$produit = $produitC->recupererProduit($rowpC['refProd']);
				foreach($produit as $rowProd){
					$onSale = false; 
					$tx = 0;
					if($eventActuel->rowCount() != 0){
						$eventActuel = $eventC->recupererEventByDate($date);
						foreach($eventActuel as $rowEvent){
							$remise = $remiseC->recupererRemise($rowProd['ref'], $rowEvent['id']);
							if($remise->rowCount() != 0){
								$onSale = true; 
								foreach($remise as $rowRemise){
									$tx = $rowRemise['taux'];
								}	
							}
						}
					}
					if($onSale){
						$nouvPrix = $rowRes['prixTotal'] - ($rowpC['qte'] * (($rowProd['prix']*$tx)/100));
					}else{
						$nouvPrix = $rowRes['prixTotal'] - ($rowpC['qte'] * $rowProd['prix']);
					}
					$commande = new Commande($rowpC['idPanier'], $nouvPrix);
					$commande1C->modifierCommande($commande, $rowpC['idPanier']);
					$contenu = $produitCommandeC->recupererProduitCommandeParPanier($rowpC['idPanier']);
					if($contenu->rowCount() == 0){
						$commande1C->supprimerCommande($rowpC['idPanier']);
					}
				}
			}
		}
		header('Location: ../cart.php');
	}
?>
<html>
	<head>
	</head>

	<body>
		<?php
			include "../../entities/Avis.php";
			include "../../core/AvisC.php";
			if(isset($_GET['refproduit'])){
				$AvisC = new AvisC();
			    $result = $AvisC->recupererAvis($_GET['refproduit']);
				foreach($result as $row){
					$refproduit = $row['refProduit'];
					$idClient = $row['idClient'];
					$note = $row['note'];
					$appreciation = $row['appreciation'];
					$dateAvis = $row['dateAvis'];
		?>
		<form method="POST">
			<table>
				<caption>Modifier Avis</caption>
				<tr>
					<td>Ref Produit</td>
					<td><input type="number" name="refproduit" value="<?php echo $refproduit ?>"></td>
				</tr>
				<tr>
					<td>Id Client</td>
					<td><input type="number" name="idClient" value="<?php echo $idClient ?>"></td>
				</tr>
				<tr>
					<td>Note</td>
					<td><input type="number" name="note" value="<?php echo $note ?>"></td>
				</tr>
				<tr>
					<td>Appreciation</td>
					<td><input type="text" name="appreciation" value="<?php echo $appreciation ?>"></td>
				</tr>
				<tr>
					<td>Date Avis</td>
					<td><input type="date" name="dateAvis" value="<?php echo $dateAvis ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="modifier" value="Modifier"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="hidden" name="id_ini" value="<?php echo $_GET['refproduit'];?>"></td>
				</tr>
			</table>
		</form>
		<?PHP
				}
			}
			if(isset($_POST['modifier'])){
				$Avis = new Avis($_POST['refproduit'], $_POST['idClient'], $_POST['note'], $_POST['appreciation'], $_POST['dateAvis']);
				$AvisC->modifierAvis($Avis, $_POST['id_ini']);
				echo $_POST['id_ini'];
				header('Location: afficherAvis.php');
			}
		?>
	</body>
</html>
<?php
	include "../../config.php";
	include "../../entities/Livraison.php";
	include "../../core/LivraisonC.php";
	if(isset($_POST['idCommande'])){
		include "../../entities/Livreur.php";
		include "../../core/LivreurC.php";
		$livreurC = new LivreurC();
		$cinLiv = $livreurC->livreurDispo();
		$livraison1 = new Livraison($_POST['idCommande'], $cinLiv, 0, NULL);
		$livraison1C = new LivraisonC();
		$livraison1C->ajouterLivraison($livraison1);
		?>
		<form method="POST" action="../checkout.php?success=true" id="f">
			<input type="hidden" value="<?php echo $_POST['idCommande']?>" name="idClient">
			<input type="hidden" value="<?php echo $_POST['idCommande']?>" name="idPanier">
		</form>
		<script type="text/javascript">
			document.getElementById("f").submit();
		</script>
		<?php	
	}else{
		echo "Verifier les champs";
	}
?>
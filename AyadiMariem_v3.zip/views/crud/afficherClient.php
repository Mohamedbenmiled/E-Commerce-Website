<?PHP
    include "../../core/ClientC.php";
    $client1C = new ClientC();
    $listeClients = $client1C->afficherClients();
?>

<table border="1">
    <tr>
        <td>Id</td>
        <td>Mail</td>
        <td>Nom</td>
        <td>Prenom</td>
        <td>Date de Naissance</td>
        <td>Adresse</td>
        <td>Date d'Inscription</td>
        <td>Supprimer</td>
        <td>Modifier</td>
    </tr>
    <?php
    	foreach($listeClients as $row){
    ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['mail']; ?></td>
        <td><?php echo $row['nom']; ?></td>
        <td><?php echo $row['prenom']; ?></td>
        <td><?php echo $row['dateNaiss']; ?></td>
        <td><?php echo $row['adresse']; ?></td>
        <td><?php echo $row['dateInsc']; ?></td>
        <td>
        	<form method="POST" action="supprimerClient.php">
	            <input type="submit" name="supprimer" value="Supprimer">
	            <input type="hidden" value="<?php echo $row['id']; ?>" name="id">
            </form>
        </td>
        <td>
        	<a href="modifierClient.php?id=<?php echo $row['id']; ?>">
            Modifier</a></td>
    </tr>
    <?php
    	}
    ?>
</table>
<?php
	class Avis{
		private $refproduit;
		private $idClient;
		private $note;
		private $appreciation;
		private $dateAvis;
		function __construct($refproduit, $idClient, $note, $appreciation, $dateAvis){
			$this->refproduit = $refproduit;
			$this->idClient= $idClient;
			$this->note = $note;
			$this->appreciation = $appreciation;
			$this->dateAvis = $dateAvis;
		}
		function getrefproduit(){
			return $this->refproduit;
		}
		function getidClient(){
			return $this->idClient;
		}
		function getnote(){
			return $this->note;
		}
		function getappreciation(){
			return $this->appreciation;
		}
		function getdateAvis(){
			return $this->dateAvis;
		}
		
		function setrefproduit($refproduit){
			$this->refproduit = $refproduit;
		}
		function setidClient($idClient){
			$this->idClient = $idClient;
		}
		function setNote($note){
			$this->note = $note;
		}
		function setappreciation($appreciation){
			$this->appreciation = $appreciation;
		}
		function setdateAvis($dateAvis){
			$this->dateAvis = $dateAvis;
		}
	}
?>
<?php
$con=mysqli_connect('localhost','root','','venividi_db');
if(mysqli_connect_errno())
{
	echo 'Failed'.mysqli_connect_error();
}
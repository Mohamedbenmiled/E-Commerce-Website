

function verif(){
  var valid = true;

  var letters = /^[a-zA-Z]+[a-zA-Z]+$/;
  var nom = document.getElementById("nom").value;
  if(nom == ""){
    document.getElementById("nom").value = '';
    document.getElementById("nom").focus();
    document.getElementById("nom").placeholder = "NAME Invalide";
    valid = false;
  }
  var type = document.getElementById("type").value;
  if(type == ""){
    document.getElementById("type").value = '';
    document.getElementById("type").focus();
    document.getElementById("type").placeholder = "TYPE Invalide";
    valid = false;
  }
  var adresse = document.getElementById("adresse").value;
  if(adresse == ""){
    document.getElementById("adresse").value = '';
    document.getElementById("adresse").focus();
    document.getElementById("adresse").placeholder = "ADDRESS Invalide";
    valid = false;
  }
  var budget = document.getElementById("budget").value;
  if(budget == ""){
    document.getElementById("budget").value = '';
    document.getElementById("budget").focus();
    document.getElementById("budget").placeholder = "BUDGET Invalide";
    valid = false;
  }



  if(!valid){
    return false;
  }

  document.getElementById("form").submit();
  return true;
}


function verif(){
  var valid = true;


  var ref = document.getElementById("ref").value;
  if(ref == ""){
    document.getElementById("ref").value = '';
    document.getElementById("ref").focus();
    document.getElementById("ref").placeholder = "REF Invalide";
    valid = false;
  }
  var idSponsor = document.getElementById("idSponsor").value;
  if(idSponsor == ""){
    document.getElementById("idSponsor").value = '';
    document.getElementById("idSponsor").focus();
    document.getElementById("idSponsor").placeholder = "IDSPONSOR Invalide";
    valid = false;
  }
  var images = document.getElementById("images").value;
  if(images == ""){
    document.getElementById("images").value = '';
    document.getElementById("images").focus();
    document.getElementById("images").placeholder = "IMAGE Invalide";
    valid = false;
  }


  var titre = document.getElementById("titre").value;
  if(titre == ""){
    document.getElementById("titre").value = '';
    document.getElementById("titre").focus();
    document.getElementById("titre").placeholder = "TITLE Invalide";
    valid = false;
  }
  var description = document.getElementById("description").value;
  if(description == ""){
    document.getElementById("description").value = '';
    document.getElementById("description").focus();
    document.getElementById("description").placeholder = "DESCRIPTION Invalide";
    valid = false;
  }



  if(!valid){
    return false;
  }
  document.getElementById("form").submit();
  return true;
}

function verif(){
	var valid = true;
	var cin = document.getElementById("id").value;
	if((cin.length != 2) || (isNaN(cin))){
		document.getElementById("id").value = '';
		document.getElementById("id").focus();
		document.getElementById("id").placeholder = "CIN Invalide";
		valid = false;
	}

	if(!valid){
		return false;
	}
	document.getElementById("form").submit();
	return true;
}

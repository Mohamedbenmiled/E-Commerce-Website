function verif(){
	var valid = true;
	var cin = document.getElementById("cin").value;
	if((cin.length != 8) || (isNaN(cin))){
		document.getElementById("cin").value = '';
		document.getElementById("cin").focus();
		document.getElementById("cin").placeholder = "CIN Invalide";
		valid = false;
	}
	var mail = document.getElementById("mail").value;
	var re = /^(?:[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&amp;'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])$/;
	if(re.test(mail) == false){
		document.getElementById("mail").value = '';
		document.getElementById("mail").focus();
		document.getElementById("mail").placeholder = "MAIL Invalide";
		valid = false;
	}
	var letters = /^[a-zA-Z]+[a-zA-Z]+$/;
	var nom = document.getElementById("nom").value;
   	if(letters.test(nom) == false){
		document.getElementById("nom").value = '';
		document.getElementById("nom").focus();
		document.getElementById("nom").placeholder = "NOM Invalide";
		valid = false;
   	}
   	var letters = /^[a-zA-Z]+[a-zA-Z]+$/;
   	var prenom = document.getElementById("prenom").value;
   	if(letters.test(prenom) == false){
		document.getElementById("prenom").value = '';
		document.getElementById("prenom").focus();
		document.getElementById("prenom").placeholder = "PRENOM Invalide";
		valid = false;
   	}
	if(!valid){
		return false;
	}
	document.getElementById("form").submit();
	return true;
}
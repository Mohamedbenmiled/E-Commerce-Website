<?php

	class EventC{
		function afficherEvent($event){
			echo "id: ".$event->getId_E()."<br>";
			echo "Nom: ".$event->getNom()."<br>";
			echo "Debut de l'event: ".$event->getDate_dbt()."<br>";
			echo "Fin de l'event: ".$event->getDate_fin()."<br>";
			
		}
		function ajouterEvent($event){
			$sql = "INSERT INTO Evenements(id, nom, date_dbt, date_fin) values(:id, :nom, :date_dbt, :date_fin)";
			$db = config::getConnexion();
			try{
		       	$req = $db->prepare($sql);
		       	$id = $event->getId_E();
		        $nom = $event->getNom();
		        $date_dbt = $event->getDate_dbt();
		        $date_fin = $event->getDate_fin();
		        $req->bindValue(':id', $id);
				$req->bindValue(':nom', $nom);
				$req->bindValue(':date_dbt', $date_dbt);
				$req->bindValue(':date_fin', $date_fin);
		        $req->execute(); 
		    }catch(Exception $e){
		        echo 'Erreur: '.$e->getMessage();
		    }
		}
		function afficherEvents(){
			$sql = "SELECT * FROM Evenements";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }	
		}
		function supprimerEvent($id){
			$sql = "DELETE FROM Evenements where id = :id";
			$db = config::getConnexion();
		    $req = $db->prepare($sql);
			$req->bindValue(':id', $id);
			try{
		        $req->execute();
		    }catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function modifierEvent($event, $id){
			$sql = "UPDATE Evenements SET id = :idNew, nom = :nom, date_dbt = :date_dbt, date_fin = :date_fin WHERE id = :id";

			$db = config::getConnexion();
			try{
		        $req = $db->prepare($sql);
				$idNew = $event->getId_E();
		        $nom = $event->getNom();
		        $date_dbt = $event->getDate_dbt();
		        $date_fin = $event->getDate_fin();

				$datas = array(':idNew' => $idNew, ':nom'=>$nom, ':date_dbt' => $date_dbt, ':date_fin'=>$date_fin);
				$req->bindValue(':idNew', $idNew);
				$req->bindValue(':nom', $nom);
				$req->bindValue(':date_dbt', $date_dbt);
				$req->bindValue(':date_fin', $date_fin);
				$req->bindValue(':id', $id);

		        $s = $req->execute();
		    }catch(Exception $e){
		        echo " Erreur ! ".$e->getMessage();
		   		echo " Les datas : " ;
		  		print_r($datas);
		    }	
		}
		function recupererEvent($id){
			$sql = "SELECT * FROM Evenements where id = $id";

			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function nbSalesByEvent(){
			$sql = "SELECT E.nom as nomEvent, count(*) as nb FROM Evenements E, Remise R WHERE R.idEvent = E.id GROUP BY E.nom ORDER BY count(*)";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
	}
?>

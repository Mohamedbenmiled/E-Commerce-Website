<?php

	class PubC{
		function afficherPub($pub){
			echo "Reference: ".$pub->getRef()."<br>";
      echo "IDSponsor: ".$pub->getIdsponsor()."<br>";
			echo "Titre: ".$pub->getTitre()."<br>";
			echo "Description: ".$pub->getDesc()."<br>";
			echo "Image: ".$pub->getImage()."<br>";

		}
		function ajouterPub($pub){
      $images = $pub->getImage();
			$sql = "INSERT INTO publicite(ref, idSponsor, images, titre, description) values(:ref, :idSponsor, '$images', :titre , :description)";
			$db = config::getConnexion();
			try{
		       	$req = $db->prepare($sql);
		       	$ref = $pub->getRef();
		        $idSponsor = $pub->getIdsponsor();
		        $description = $pub->getDesc();
		        $titre = $pub->getTitre();


		        $req->bindValue(':ref', $ref);
		        $req->bindValue(':idSponsor', $idSponsor);

				$req->bindValue(':titre', $titre);
				$req->bindValue(':description', $description);
		        $req->execute(); 
		    }catch(Exception $e){
		        echo 'Erreur: '.$e->getMessage();
		    }
		}
		function afficherPubs(){
			$sql = "SELECT * FROM publicite";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }	
		}

		function supprimerPub($ref){
			$sql = "DELETE FROM publicite where ref = :ref";
			$db = config::getConnexion();
		    $req = $db->prepare($sql);
			$req->bindValue(':ref', $ref);
			try{
		        $req->execute();
		    }catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function modifierPub($pub, $ref){
      $images = $pub->getImage();
			$sql = "UPDATE `publicite` SET `ref` = ':refNew', `idSponsor` = ':idSponsor', `images` = '$images',  `titre` = ':titre', `description` = ':description'  WHERE `ref` = ':ref' ";

			$db = config::getConnexion();
			try{
		        $req = $db->prepare($sql);
				$refNew = $pub->getRef();
				$idSponsor = $pub->getIdsponsor();
		        $titre = $pub->getTitre();
		       	$description = $pub->getDesc();
		       	echo $refNew;
        echo $idSponsor;
        echo $titre;
        echo $description;


				$req->bindValue(':refNew', $refNew);
				$req->bindValue(':idSponsor', $idSponsor);

				$req->bindValue(':titre', $titre);
				$req->bindValue(':description', $description);
				$req->bindValue(':ref', $ref);
		        $s = $req->execute();

		    }catch(Exception $e){
		        echo " Erreur ! ".$e->getMessage();


		    }	
		}
		function recupererPub($ref){
			$sql = "SELECT * FROM publicite where ref = $ref";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}   catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}

	}
?>

<?php
	//include "../config.php";
	class ProduitCommandeC{
		function afficherProduitCommande($produitCommande){
			echo "Reference Produit: ".$produitCommande->getRefProd()."<br>";
			echo "Id Commande: ".$produitCommande->getIdCommande()."<br>";
			echo "Quantite: ".$produitCommande->getQte()."<br>";
		}
		function ajouterProduitCommande($produitCommande){
			$sql = "INSERT INTO ProduitCommande values(:refProd, :idCommande, :qte)";
			$db = config::getConnexion();
			try{
		       	$req = $db->prepare($sql);
		       	$refProd = $produitCommande->getRefProd();
		        $idCommande = $produitCommande->getIdCommande();
		        $qte = $produitCommande->getQte();
		        $req->bindValue(':refProd', $refProd);
				$req->bindValue(':idCommande', $idCommande);
				$req->bindValue(':qte', $qte);
		        $req->execute(); 
		    }catch(Exception $e){
		        echo 'Erreur: '.$e->getMessage();
		    }
		}
		function afficherProduitCommandes(){
			$sql = "SELECT * FROM ProduitCommande";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }	
		}
		function supprimerProduitCommande($refProd, $idCommande){
			$sql = "DELETE FROM ProduitCommande where refProd = :refProd and idCommande = :idCommande";
			$db = config::getConnexion();
		    $req = $db->prepare($sql);
		    $req->bindValue(':refProd', $refProd);
			$req->bindValue(':idCommande', $idCommande);
			try{
		        $req->execute();
		    }catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function modifierProduitCommande($produitCommande, $refProd, $idCommande){
			$sql = "UPDATE ProduitCommande SET qte = :qte WHERE refProd = :refProd AND idCommande = :idCommande";
			$db = config::getConnexion();
			try{
		        $req = $db->prepare($sql);
		        $qte = $produitCommande->getQte();
				$datas = array(':refProd' => $refProd, ':idCommande' => $idCommande, ':qte' => $qte);
				$req->bindValue(':refProd', $refProd);
				$req->bindValue(':idCommande', $idCommande);
				$req->bindValue(':qte', $qte);
		        $s = $req->execute();
		    }catch(Exception $e){
		        echo " Erreur ! ".$e->getMessage();
		   		echo " Les datas : " ;
		  		print_r($datas);
		    }	
		}
		function recupererProduitCommande($refProd, $idCommande){
			$sql = "SELECT * FROM ProduitCommande WHERE refProd = $refProd AND idCommande = $idCommande";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function recupererProduitCommandeParCommande($idCommande){
			$sql = "SELECT * FROM ProduitCommande where idCommande = $idCommande";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function getCartNbForClient($idClient){
			$sql = "SELECT PC.qte AS Q
			 		FROM ProduitCommande PC, Commande C
			 		WHERE C.idClient = $idClient 
			 		  AND PC.idCommande = C.id 
			 		  AND C.etat = 1";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				$nb = 0;
				foreach($liste as $row){
					$nb += $row['Q'];
				}
				return $nb;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function recupererProduitsCommandesCourantParClient($idClient){
			$sql = "SELECT * 
					FROM ProduitCommande PC, Commande C
					WHERE C.idClient = $idClient 
					  AND PC.idCommande = C.id 
					  AND C.etat = 1";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function recupererNbProduitsDansCommande($idCommande){
			$sql = "SELECT PC.qte AS Q FROM ProduitCommande PC, Commande C WHERE C.id = $idCommande AND PC.idCommande = C.id";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				$nb = 0;
				foreach($liste as $row){
					$nb += $row['Q'];
				}
				return $nb;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
	}
?>
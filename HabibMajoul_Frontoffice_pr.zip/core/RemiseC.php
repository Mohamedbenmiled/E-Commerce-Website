<?php
	//include "../config.php";
	class RemiseC{
		function afficherRemise($remise){
			echo "Reference Produit: ".$remise->getRefProd()."<br>";
			echo "ID evenement: ".$remise->getId_E()."<br>";
			echo "Taux: ".$remise->getTaux()."<br>";
		}
		function ajouterRemise($remise){
			$sql = "INSERT INTO Remise(refProd, Id_E, taux) values(:refProd, :Id_E, :taux)";
			$db = config::getConnexion();
			try{
		       	$req = $db->prepare($sql);
		       	$refProd = $remise->getRefProd();
		       	$Id_E = $remise->getId_E();
		        $taux = $remise->getTaux();
		        $req->bindValue(':refProd', $refProd);
				$req->bindValue(':Id_E', $Id_E);
				$req->bindValue(':taux', $taux);
		        $req->execute(); 
		    }catch(Exception $e){
		        echo 'Erreur: '.$e->getMessage();
		    }
		}
		function afficherRemises(){
			$sql = "SELECT * FROM Remise";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }	
		}
		function supprimerRemise($refProd){
			$sql = "DELETE FROM Remise where refProd = :refProd";
			$db = config::getConnexion();
		    $req = $db->prepare($sql);
			$req->bindValue(':refProd', $id);
			try{
		        $req->execute();
		    }catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function modifierRemise($remise, $refProd){
			$sql = "UPDATE Remise SET refProd = :refProdNew, Id_E = :Id_E, taux = :taux WHERE refProd = :refProd";
			$db = config::getConnexion();
			try{
		        $req = $db->prepare($sql);
		        $refProdNew = $remise->getRefProd();
				$Id_E = $remise->getID_E();
				$taux = $remise->getTaux();
				$datas = array(':refProdNew' => $refProdNew, ':Id_E' => $Id_E, ':taux' => $taux);
				$req->bindValue(':refProdNew', $refProdNew);
				$req->bindValue(':Id_E', $Id_E);
				$req->bindValue(':´taux', $taux);
		        $s = $req->execute();
		    }catch(Exception $e){
		        echo " Erreur ! ".$e->getMessage();
		   		echo " Les datas : " ;
		  		print_r($datas);
		    }	
		}
		function recupererRemise($refProd, $idEvent){
			$sql = "SELECT * FROM Remise where refProduit = $refProd AND idEvent = $idEvent";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
	}
?>
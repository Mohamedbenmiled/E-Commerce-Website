<?php
	$idClient = 1;
	include "../config.php";
	include "../entities/ProduitCommande.php";
	include "../core/ProduitCommandeC.php";
	include "../entities/Commande.php";
	include "../core/CommandeC.php";
	include "../entities/Livraison.php";
	include "../core/LivraisonC.php";
	include "../entities/Event.php";
	include "../core/EventC.php";
	include "../entities/Remise.php";
	include "../core/RemiseC.php";
	include "../entities/Produit.php";
	include "../core/ProduitC.php";
	$produitCommandeC = new ProduitCommandeC();
	$commandeC = new CommandeC();
	$livraisonC = new LivraisonC();
	$remiseC = new RemiseC();
	$eventC = new EventC();
	$produitC = new ProduitC();
	$idCommande = $commandeC->recupererIdParClientEtEtat($idClient);
	$commande = $commandeC->recupererCommande($_GET['id']);
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Veni Vidi</title>
		<link rel="stylesheet" type="text/css" href="../stylesheet.css">
	</head>

	<body>
		<div class="topBar">
			<table style="width: 95%; height: 100%">
				<tr>
					<td style="width: 71%; padding-left: 5%">
						<a class="venividi" href="index.php">Veni Vidi</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="index.php">Home</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="about.php">About</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="contact.php">Contact</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="products.php">Shop</a>
					</td>
					<td style="width: 6%">
						<a class="choix" href="cart.php">
							<img src="../images/cart.png" alt="Cart" class="cart">
							<?php
								$nb = $produitCommandeC->getCartNbForClient($idClient);
							?>
							<label class="cartNb"><?php echo $nb;?></label>
						</a>
					</td>
				</tr>		
			</table>	
		</div>
		<div class="cartDiv" align="center">	
			<div class="cartTitleBox" align="left">
				<label class="cartTitle">ORDER DETAILS</label>
			</div>
			<?php foreach($commande as $rowCom){
				$etatLiv = $livraisonC->recupererEtatParIdCommande($rowCom['id']);
				$nbPc = $produitCommandeC->recupererNbProduitsDansCommande($_GET['id']);
				$listePC = $produitCommandeC->recupererProduitCommandeParCommande($_GET['id']);
				$date = date("Y/m/d H:i:s");
				$eventActuel = $eventC->recupererEventByDate($date);
				$total = 0;
				foreach($listePC as $row){
					$prixTotal = 0;
					$refProd = $row['refProd'];
					$product = $produitC->recupererProduit($refProd);
					foreach($product as $rowProd){
						$onSale = false; 
						$tx = 0;	
						if($eventActuel->rowCount() != 0){
							$eventActuel = $eventC->recupererEventByDate($date);
							foreach($eventActuel as $rowEvent){
								$remise = $remiseC->recupererRemise($rowProd['ref'], $rowEvent['id']);
								if($remise->rowCount() != 0){
									$onSale = true; 
									foreach($remise as $rowRemise){
										$tx = $rowRemise['taux'];
									}	
								}
							}
						}
					}
					$prix = 0;
					if($onSale == true){
						$prix = $rowProd['prix'] * $tx / 100;
					}else{
						$prix = $rowProd['prix'];
					}
					$prixTotal += $prix * $row['qte'];
					$total += $prixTotal;
				}
			?>
			<table class="infoCommandeDetails" cellspacing="10px">
				<tr>
					<td>
						<label class="lbn">ORDER N°<?php echo $rowCom['id'];?></label>
					</td>
				</tr>
				<tr>
					<td>
						<span class="placedOn" style="margin-right: 6px;">Status </span>
						<?php if($etatLiv == 0){?>
							<label class="deliveredOn" style="color: rgb(255, 200, 61); font-size: 12px;"><span style="font-size: 11px; vertical-align: center;">&#8987;</span> &nbsp;PENDING</label>
						<?php }else{ if($etatLiv == 1){?>
							<label class="deliveredOn" id="or2" style="font-size: 12px;"><span class="tickedOrd" id="or2v">⟳</span> IN PROGRESS</label>
						<?php }else{ ?>
							<label class="deliveredOn" style="font-size: 12px;"><span class="tickedOrd">🗸</span> DELIVERED ON 04-06-2019</label>
						<?php }}?>
					</td>
				</tr>
				<tr>
					<td>
						<label class="placedOn"><?php echo $nbPc; if($nbPc == 1) echo " item"; else echo " items";?></label>
					</td>
				</tr>
				<tr>
					<td>
						<label class="placedOn">Placed on <span style="font-weight: bold;"><?php echo $rowCom['datePlace'];?></span></label>
					</td>
				</tr>
				<tr>
					<td style="padding-bottom: 30px">
						<label class="placedOn">Total <span style="font-weight: bold;"><?php echo $total;?> TND</span></label>
					</td>
				</tr>
			</table>
			<table class="tablePC">
				<tr>
					<td>
						<label class="lbn">ORDER LIST</label>
					</td>
				</tr>
				<?php
					$listePC = $produitCommandeC->recupererProduitCommandeParCommande($_GET['id']);
					foreach($listePC as $rowPC){
						$produitReq = $produitC->recupererProduit($rowPC['refProd']);
						foreach($produitReq as $produit)
				?>
				<tr>
					<td align="center">
						<table class="produitCommadeTable" style="height: 100%; width: 100%">
							<tr style="height: 100%; width: 100%">
								<td align="center" style="width: 14%; height: 115px;">
									<div style="background-image: url('../<?php echo $produit['images'];?>/0.png');" class="orderImageProduit">
									</div>
								</td>
								<td>
									<table style="height: 80%">
										<tr>
											<td class="td1pc">
												<label class="lbn" style="font-size: 16px;"><?php echo $produit['label'];?></label>
											</td>
										</tr>
										<tr>
											<td class="td2pc" >
												<label class="placedOn">Quantity &nbsp; &nbsp; &nbsp; &nbsp;<?php echo $rowPC['qte'];?></label>
											</td>
										</tr>
										<tr>
											<td class="td3pc">
												<?php 
													$date = $rowCom['datePlace'];
													$eventActuel = $eventC->recupererEventByDate($date);
													$prixTotal = 0;
													$onSale = false; 
													$tx = 0;	
													if($eventActuel->rowCount() != 0){
														$eventActuel = $eventC->recupererEventByDate($date);
														foreach($eventActuel as $rowEvent){
															$remise = $remiseC->recupererRemise($produit['ref'], $rowEvent['id']);
															if($remise->rowCount() != 0){
																$onSale = true; 
																foreach($remise as $rowRemise){
																	$tx = $rowRemise['taux'];
																}	
															}
														}
													}
													$prix = 0;
													if($onSale == true){
														$prix = $produit['prix'] * $tx / 100;
													}else{
														$prix = $produit['prix'];
													}
													$prixTotal += $prix * $rowPC['qte'];
												?>
												<label class="placedOn">Total Price &nbsp; &nbsp; <?php echo $prixTotal;?> TND</label>
											</td>
										</tr>
									</table>
								</td>	
							</tr>
						</table>
					</td>
				</tr>
				<?php
					}
				?>
			</table>
			<?php } ?>
		</div>
		<div class="prdBottomImg" style="margin-top: 296px;">
		</div>
	</body>
</html>
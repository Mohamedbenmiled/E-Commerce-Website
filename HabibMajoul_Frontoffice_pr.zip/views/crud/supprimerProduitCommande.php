<?php
	include "../../config.php";
	include "../../core/ProduitCommandeC.php";
	include "../../entities/ProduitCommande.php";
	include "../../core/CommandeC.php";
	include "../../entities/Commande.php";
	$produitCommandeC = new ProduitCommandeC();
	$commandeC = new CommandeC();
	if(isset($_POST["refProd"]) && isset($_POST["idCommande"])){
		$produitCommandeC->supprimerProduitCommande($_POST["refProd"], $_POST["idCommande"]);
		$nbProduits = $commandeC->nbProduits($_POST["idCommande"]);
		if($nbProduits == 0){
			$commandeC->supprimerCommande($_POST["idCommande"]);
		}
		header('Location: ../cart.php');
	}else{
		header('Location: ../cart.php');
	}
?>
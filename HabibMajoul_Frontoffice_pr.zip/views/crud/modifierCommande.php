<html>
	<head>
	</head>

	<body>
		<?php
			include "../../entities/Commande.php";
			include "../../core/CommandeC.php";
			if(isset($_GET['id'])){
				$CommandeC = new CommandeC();
			    $result = $CommandeC->recupererCommande($_GET['id']);
				foreach($result as $row){
					$id = $row['id'];
					$prixTotal = $row['prixTotal'];

		?>
		<form method="POST">
			<table>
				<caption>Modifier Commande</caption>
				<tr>
					<td>Id</td>
					<td><input type="number" name="id" value="<?php echo $id ?>"></td>
				</tr>
				<tr>
					<td>Nom</td>
					<td><input type="text" step="0.01" name="prixTotal" value="<?php echo $prixTotal ?>"></td>
				</tr>
				
				<tr>
					<td></td>
					<td><input type="submit" name="modifier" value="Modifier"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="hidden" name="id_ini" value="<?php echo $_GET['id'];?>"></td>
				</tr>
			</table>
		</form>
		<?PHP
				}
			}
			if(isset($_POST['modifier'])){
				$Commande = new Commande($_POST['id'], $_POST['prixTotal']);
				$CommandeC->modifierCommande($Commande, $_POST['id_ini']);
				echo $_POST['id_ini'];
				header('Location: afficherCommande.php');
			}
		?>
	</body>
</html>
<?php
	include "../../entities/Client.php";
	include "../../core/ClientC.php";
	if(isset($_POST['id']) and isset($_POST['mail']) and isset($_POST['nom']) and isset($_POST['prenom']) and isset($_POST['dateNaiss']) and isset($_POST['adresse']) and isset($_POST['dateInsc'])){
	$client1 = new Client($_POST['id'], $_POST['mail'], $_POST['nom'], $_POST['prenom'], $_POST['dateNaiss'], $_POST['adresse'], $_POST['dateInsc']);
		$client1C = new ClientC();
		$client1C->ajouterClient($client1);
		header('Location: afficherClient.php');	
	}else{
		echo "Verifier les champs";
	}
?>
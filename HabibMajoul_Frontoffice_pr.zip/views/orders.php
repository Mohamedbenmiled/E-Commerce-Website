<?php
	$idClient = 1;
	include "../config.php";
	include "../entities/ProduitCommande.php";
	include "../core/ProduitCommandeC.php";
	include "../entities/Commande.php";
	include "../core/CommandeC.php";
	include "../entities/Livraison.php";
	include "../core/LivraisonC.php";
	$produitCommande1C = new ProduitCommandeC();
	$commandeC = new CommandeC();
	$livraisonC = new LivraisonC();
	$idCommande = $commandeC->recupererIdParClientEtEtat($idClient);
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Veni Vidi</title>
		<link rel="stylesheet" type="text/css" href="../stylesheet.css">
	</head>

	<body>
		<div class="topBar">
			<table style="width: 95%; height: 100%">
				<tr>
					<td style="width: 71%; padding-left: 5%">
						<a class="venividi" href="index.php">Veni Vidi</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="index.php">Home</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="about.php">About</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="contact.php">Contact</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="products.php">Shop</a>
					</td>
					<td style="width: 6%">
						<a class="choix" href="cart.php">
							<img src="../images/cart.png" alt="Cart" class="cart">
							<?php
								$nb = $produitCommande1C->getCartNbForClient($idClient);
							?>
							<label class="cartNb"><?php echo $nb;?></label>
						</a>
					</td>
				</tr>		
			</table>	
		</div>
		<div class="cartDiv" align="center">	
			<div class="cartTitleBox" align="left">
				<label class="cartTitle">MY ORDERS</label>
			</div>
			<?php 
				$listeCommandes = $commandeC->recupererCommandesParIdClientEtEtat($idClient);
				foreach($listeCommandes as $rowCom){
					$etatLiv = $livraisonC->recupererEtatParIdCommande($rowCom['id']);
			?>
			<table class="tableOrders">
				<tr>
					<td class="imageOrderTd" align="center">
						<div class="divImageOrder">
						</div>
					</td>
					<td class="orderStuffTd">
						<table class="minitableStuffOrder">
							<tr>
								<td class="td1order">
									<label class="lbn">ORDER N°<?php echo $rowCom['id'];?></label>
								</td>
							</tr>
							<tr>
								<td class="td2order">
									<label class="placedOn">Placed <?php echo $rowCom['datePlace'];?></label>
								</td>
							</tr>
							<tr>
								<td class="td3order">
									<?php if($etatLiv == 0){?>
										<label class="deliveredOn" style="color: rgb(255, 200, 61)"><span>&#8987;</span> &nbsp;PENDING</label>
									<?php }else{ if($etatLiv == 1){?>
										<label class="deliveredOn" id="or2"><span class="tickedOrd" id="or2v">⟳</span> IN PROGRESS</label>
									<?php }else{ ?>
										<label class="deliveredOn"><span class="tickedOrd">🗸</span> DELIVERED ON 04-06-2019</label>
									<?php }}?>
								</td>
							</tr>
						</table>
					</td>
					<td class="orderRightTd" align="right">
						<input type="button" value="DETAILS" class="buttonDetails" onclick="location.href='details.php?id=<?php echo $rowCom['id'];?>'">
					</td>
				</tr>	
			</table>
			<?php 
				}
			?>
		</div>
		<div class="prdBottomImg" style="margin-top: 296px;">
		</div>
	</body>
</html>
<?php
	$idClient = 1;
	include "../config.php";
	include "../entities/ProduitCommande.php";
	include "../core/ProduitCommandeC.php";
	include "../entities/Client.php";
	include "../core/ClientC.php";
	$produitCommande1C = new ProduitCommandeC();
	$clientC = new ClientC();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Veni Vidi</title>
		<link rel="stylesheet" type="text/css" href="../stylesheet.css">
	</head>

	<body>
		<?php
			$client = $clientC->recupererClient($idClient);
		?>
		<div class="topBar">
			<table style="width: 95%; height: 100%">
				<tr>
					<td style="width: 71%; padding-left: 5%">
						<a class="venividi" href="index.php">Veni Vidi</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="index.php">Home</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="about.php">About</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="contact.php">Contact</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="products.php">Shop</a>
					</td>
					<td style="width: 6%">
						<a class="choix" href="cart.php">
							<img src="../images/cart.png" alt="Cart" class="cart">
							<?php 
								$nb = $produitCommande1C->getCartNbForClient($idClient);
							?>
							<label class="cartNb"><?php echo $nb;?></label>
						</a>
					</td>
				</tr>		
			</table>	
		</div>
		<div class="ctcFirst" align="center"><br><br><br><br><br><br><br><br><br>
			<label class="contactTitle">CONTACT</label>
			<p class="contactText">Feel free to contact us at your convenience and we’ll be happy to get in touch with you.</p>
		</div>	
		<?php
			if(isset($_GET['success'])){
				if($_GET['success'] == true){
				?>
					<center style="padding-top: 20px;">	
						<div class="sucessAdd" align="left">
							<table style="width: 100%; height: 100%" id="s">
								<tr style="width: 100%; height: 100%">
									<td>
										<label class="checkmark">🗸</label>
										<label class="sucessText">Email successfully sent.</label>
									</td>	
								</tr>
							</table>
							</label>
						</div>
					</center>
				<?php
				}
			}
			?>
		<table class="tableHalves">
			<tr>
				<td class="half1">
					<table class="tableInfos">
						<tr>
							<th colspan="2">
								<p class="infoText">Our customer service is here to help providing information on your inquiries and advice on your purchases.</p>
							</th>
						</tr>	
						<tr>
							<th>
								<label class="infoText">Phone Number:</label>
							</th>
							<td>
								<label class="infoText">+216 99 666 217</label>
							</td>
						</tr>
						<tr>
							<th>
								<label class="infoText">Email:</label>
							</th>
							<td>
								<label class="infoText">contact@venividi.com</label>
							</td>
						</tr>
						<tr>
							<th>
								<label class="infoText">Monday to Friday:</label>
							</th>
							<td>
								<label class="infoText">9:30am - 6pm</label>
							</td>
						</tr>
						<tr>
							<th>
								<label class="infoText">Saturday:</label>
							</th>
							<td>
								<label class="infoText">9:30am - 4pm</label>
							</td>
						</tr>
						<tr>
							<th>
								<label class="infoText">Sunday:</label>
							</th>
							<td>
								<label class="infoText">9:30am - 1pm</label>
							</td>
						</tr>
						<tr>
							<td colspan="2" align="center">
								<p>
									<img src="../images/facebook.png" alt="facebook" class="contactIcons" onclick="location.href='http://facebook.com';">
									<img src="../images/instagram.png" alt="instagram" class="contactIcons" onclick="location.href='http://instagram.com';">	
									<img src="../images/twitter.png" alt="twitter" class="contactIcons" onclick="location.href='http://twitter.com';">	
								</p>
							</td>
						</tr>
					</table>
				</td> 
				<td class="half2">
					<form method="post" action="crud/ajoutReclamation.php">
						<table class="tableContact">
							<tr>
								<td class="tdCtc">
									<label class="ctcLabel">Subject *</label>
								</td>
							</tr>	
							<tr>
								<td>
									<select name="subject" class="selectSubject">
										<option value="0">Appreciation</option>
										<option value="1">Information</option>
										<option value="2">Request</option>
										<option value="2">Delivery</option>
										<option value="3">Other...</option>
									</select>
								</td>
							</tr>	
							<tr>
								<td class="tdCtc">
									<label class="ctcLabel">Email *</label>
								</td>
							</tr>	
							<tr>
								<td>
									<?php 
										foreach($client as $row){
									?>
									<input type="mail" placeholder="email@example.com" name="mail" class="champs" value="<?php echo $row['mail'];?>" disabled>
									<?php
										}
									?>
								</td>
							</tr>	
							<tr>
								<td class="tdCtc">
									<label class="ctcLabel">Message *</label>
								</td>
							</tr>	
							<tr>
								<td>
									<textarea name="message" placeholder="Your message here..." class="champsMessage"></textarea>
									<input type="hidden" name="idclient" value="<?php echo $idClient; ?>">
								</td>
							</tr>	
							<tr>
								<td class="tdSend">
									<input type="SUBMIT" value="SUBMIT" class="send">
								</td>
							</tr>	
						</table> 
					</form>
				</td>	
			</tr>			
		</table>
		<div class="bottomContact">
		</div>
		<div class="preFooter">
		</div>
		<div class="footer">
		</div>
	</body>
</html>
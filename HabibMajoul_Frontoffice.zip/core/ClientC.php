<?php
	//include "../config.php";
	class ClientC{
		function afficherClient($client){
			echo "Id: ".$client->getId()."<br>";
			echo "Mail: ".$client->getMail()."<br>";
			echo "Nom: ".$client->getNom()."<br>";
			echo "Prenom: ".$client->getPrenom()."<br>";
			echo "Date de Naissance: ".$client->getDateNaiss()."<br>";
			echo "Adresse: ".$client->getAdresse()."<br>";
			echo "Date d'Inscription".$client->getDateInsc()."<br>";
		}
		function ajouterClient($client){
			$sql = "INSERT INTO Client(id, mail, nom, prenom, dateNaiss, adresse, dateInsc) values(:id, :mail, :nom, :prenom, :dateNaiss, :adresse, :dateInsc)";
			$db = config::getConnexion();
			try{
		       	$req = $db->prepare($sql);
		       	$id = $client->getId();
		       	$mail = $client->getMail();
		        $nom = $client->getNom();
		        $prenom = $client->getPrenom();
		        $dateNaiss = $client->getDateNaiss();
		        $adresse = $client->getAdresse();
		        $dateInsc = $client->getDateInsc();
		        $req->bindValue(':id', $id);
		        $req->bindValue(':mail', $mail);
				$req->bindValue(':nom', $nom);
				$req->bindValue(':prenom', $prenom);
				$req->bindValue(':dateNaiss', $dateNaiss);
				$req->bindValue(':adresse', $adresse);
				$req->bindValue(':dateInsc', $dateInsc);
		        $req->execute(); 
		    }catch(Exception $e){
		        echo 'Erreur: '.$e->getMessage();
		    }
		}
		function afficherClients(){
			$sql = "SELECT * FROM Client";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }	
		}
		function supprimerClient($id){
			$sql = "DELETE FROM Client where id = :id";
			$db = config::getConnexion();
		    $req = $db->prepare($sql);
			$req->bindValue(':id', $id);
			try{
		        $req->execute();
		    }catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function modifierClient($client, $id){
			$sql = "UPDATE Client SET id = :idNew, mail = :mail, nom = :nom, prenom = :prenom, dateNaiss = :dateNaiss, adresse = :adresse, dateInsc = :dateInsc WHERE id = :id";
			$db = config::getConnexion();
			try{
		        $req = $db->prepare($sql);
				$idNew = $client->getId();
				$mail = $client->getMail();
		        $nom = $client->getNom();
		        $prenom = $client->getPrenom();
		        $dateNaiss = $client->getDateNaiss();
		        $adresse = $client->getAdresse();
		        $dateInsc = $client->getDateInsc();
				$datas = array(':idNew' => $idNew, ':mail' => $mail, ':nom'=>$nom, ':prenom'=>$prenom, ':dateNaiss' => $dateNaiss, ':adresse'=>$adresse, ':dateInsc'=>$dateInsc);
				$req->bindValue(':idNew', $idNew);
				$req->bindValue(':mail', $mail);
				$req->bindValue(':nom', $nom);
				$req->bindValue(':prenom', $prenom);
				$req->bindValue(':dateNaiss', $dateNaiss);
				$req->bindValue(':adresse', $adresse);
				$req->bindValue(':dateInsc', $dateInsc);
				$req->bindValue(':id', $id);
		        $s = $req->execute();
		    }catch(Exception $e){
		        echo " Erreur ! ".$e->getMessage();
		   		echo " Les datas : " ;
		  		print_r($datas);
		    }	
		}
		function recupererClient($id){
			$sql = "SELECT * FROM Client where id = $id";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function recupererMail($id){
			$sql = "SELECT mail FROM Client where id = $id";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				foreach($liste as $row){
					return $row['mail'];
				}
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
	}
?>
<?php
	//include "../config.php";
	class AvisC{
		function afficherAvi($avis){
			echo "ref Produits: ".$avis->getrefproduit()."<br>";
			echo "id Client: ".$avis->getidClient()."<br>";
			echo "note: ".$avis->getnote()."<br>";
			echo "appreciation: ".$avis->getappreciation()."<br>";
			echo "date Avis: ".$avis->getdateAvis()."<br>";
		}

		function ajouterAvis($avis){
			$sql = "INSERT INTO avis(refProduit, idClient, note, appreciation, dateAvis) values(:refProduit, :idClient, :note, :appreciation, :dateAvis)";
			$db = config::getConnexion();
			try{
		       	$req = $db->prepare($sql);
		       	$refproduit = $avis->getrefproduit();
		       	$idClient = $avis->getidClient();
		        $note = $avis->getnote();
		        $appreciation = $avis->getappreciation();
		        $dateAvis= $avis->getdateAvis();
		        $req->bindValue(':refProduit', $refproduit);
		        $req->bindValue(':idClient', $idClient);
				$req->bindValue(':note', $note);
				$req->bindValue(':appreciation', $appreciation);
				$req->bindValue(':dateAvis', $dateAvis);
				$req->execute(); 
		    }catch(Exception $e){
		        echo 'Erreur: '.$e->getMessage();
		    }
		}
		function afficherAvis(){
			$sql = "SELECT * FROM Avis";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }	
		}
		function afficherAvisSorted(){
			$sql = "SELECT * FROM Avis ORDER BY dateAvis DESC";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }	
		}
		function supprimerAvis($refproduit, $idClient){
			$sql = "DELETE FROM Avis WHERE refproduit = :refproduit AND idClient = :idClient";
			$db = config::getConnexion();
		    $req = $db->prepare($sql);
			$req->bindValue(':refproduit', $refproduit);
			$req->bindValue(':idClient', $idClient);
			try{
		        $req->execute();
		    }catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function modifierAvis($avis, $refproduit, $idClient){
			$sql = "UPDATE Avis SET note = :note, appreciation = :appreciation WHERE refProduit = :refproduit AND idClient = :idClient";
			$db = config::getConnexion();
			try{
		        $req = $db->prepare($sql);
				$refproduitNew = $avis->getrefproduit();
				$idClient = $avis->getidClient();
		        $note = $avis->getnote();
		        $appreciation = $avis->getappreciation();
				$req->bindValue(':refproduit', $refproduit);
				$req->bindValue(':idClient', $idClient);
				$req->bindValue(':note', $note);
				$req->bindValue(':appreciation', $appreciation);
		        $s = $req->execute();
		    }catch(Exception $e){
		        echo " Erreur ! ".$e->getMessage();
		    }	
		}
		function recupereravis($refproduit){
			$sql = "SELECT * FROM Avis where refproduit = $refproduit ORDER BY dateAvis";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function recupereravisDeClient($idClient, $ref){
			$sql = "SELECT * FROM Avis where idClient = $idClient AND refproduit = $ref";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function countAvisByRefProd($refProduit){
			$sql = "SELECT COUNT(*) FROM Avis WHERE refProduit = $refProduit";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
	}
?>
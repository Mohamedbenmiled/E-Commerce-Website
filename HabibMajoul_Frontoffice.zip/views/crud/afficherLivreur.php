<?PHP
    include "../../core/LivreurC.php";
    $livreur1C = new LivreurC();
    $listeLivreurs = $livreur1C->afficherLivreurs();
?>

<table border="1">
    <tr>
        <td>Cin</td>
        <td>Mail</td>
        <td>Nom</td>
        <td>Prenom</td>
        <td>Date de Naissance</td>
        <td>Supprimer</td>
        <td>Modifier</td>
    </tr>
    <?php
    	foreach($listeLivreurs as $row){
    ?>
    <tr>
        <td><?php echo $row['cin']; ?></td>
        <td><?php echo $row['mail']; ?></td>
        <td><?php echo $row['nom']; ?></td>
        <td><?php echo $row['prenom']; ?></td>
        <td><?php echo $row['dateNaiss']; ?></td>
        <td>
        	<form method="POST" action="supprimerLivreur.php">
	            <input type="submit" name="supprimer" value="Supprimer">
	            <input type="hidden" value="<?php echo $row['cin']; ?>" name="cin">
            </form>
        </td>
        <td>
        	<a href="modifierLivreur.php?cin=<?php echo $row['cin']; ?>">
            Modifier</a></td>
    </tr>
    <?php
    	}
    ?>
</table>
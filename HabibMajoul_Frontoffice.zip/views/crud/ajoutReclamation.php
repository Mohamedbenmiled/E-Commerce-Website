<?php
	include "../../config.php";
	include "../../entities/Reclamation.php";
	include "../../core/ReclamationC.php";
	if (isset($_POST['idclient']) and isset($_POST['subject']) and isset($_POST['message'])){
	$rec1 = new Reclamation($_POST['idclient'],$_POST['idclient'], $_POST['subject'], $_POST['message']);
		$rec1C = new ReclamationC();
		$rec1C->ajouterReclamation($rec1);
		header('Location: ../contact.php?success=true#s');	
	}else{
		echo "Verifier les champs";
	}
?>
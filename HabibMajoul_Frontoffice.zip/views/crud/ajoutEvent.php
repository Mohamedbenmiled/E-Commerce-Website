<?php
	include "../entities/Event.php";
	include "../core/EventC.php";
	if(isset($_POST['Id_E']) and isset($_POST['nom']) and isset($_POST['date_dbt']) and isset($_POST['date_fin'])){
		$event1 = new Event($_POST['Id_E'], $_POST['nom'], $_POST['date_dbt'], $_POST['date_fin']);
		$event1C = new EventC();
		$event1C->ajouterEvent($event1);
		header('Location: afficherEvent.php');	
	}else{
		echo "Verifier les champs";
	}
?>
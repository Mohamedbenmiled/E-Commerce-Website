<?php
	$idClient = 1;
	include "../config.php";
	include "../entities/ProduitCommande.php";
	include "../core/ProduitCommandeC.php";
	include "../entities/Event.php";
	include "../core/EventC.php";
	include "../core/RemiseC.php";
	include "../entities/Remise.php";
	include "../entities/Produit.php";
	include "../core/ProduitC.php";
	include "../core/CommandeC.php";
	$produitCommande1C = new ProduitCommandeC();
	$commandeC = new CommandeC();	
	$remiseC = new RemiseC();
	$eventC = new EventC();
	$produit1C = new ProduitC();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Veni Vidi</title>
		<link rel="stylesheet" type="text/css" href="../stylesheet.css">
	</head>

	<body>
		<div class="topBar">
			<table style="width: 95%; height: 100%">
				<tr>
					<td style="width: 71%; padding-left: 5%">
						<a class="venividi" href="index.php">Veni Vidi</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="index.php">Home</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="about.php">About</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="contact.php">Contact</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="products.php">Shop</a>
					</td>
					<td style="width: 6%">
						<a class="choix" href="cart.php">
							<img src="../images/cart.png" alt="Cart" class="cart">
							<?php
								$nb = $produitCommande1C->getCartNbForClient($idClient);
							?>
							<label class="cartNb"><?php echo $nb;?></label>
						</a>
					</td>
				</tr>		
			</table>	
		</div>
		<div class="cartDiv" align="center">	
			<div class="cartTitleBox" align="left">
				<label class="cartTitle">CART</label>
			</div>
			<?php
			if(isset($_GET['success'])){
				if($_GET['success'] == true){
				?>
					<center style="padding-top: 20px;">	
						<div class="sucessAdd" align="left">
							<table style="width: 100%; height: 100%">
								<tr style="width: 100%; height: 100%">
									<td>
										<label class="checkmark">🗸</label>
										<label class="sucessText">Cart updated.</label>
									</td>	
								</tr>
							</table>
							</label>
						</div>
					</center>
				<?php
				}
			}
			?>
			<?php 	
				$date = date("Y/m/d H:i:s");
				$eventActuel = $eventC->recupererEventByDate($date);
				$prd = $produitCommande1C->recupererProduitsCommandesCourantParClient($idClient);
				$x = 0;
				foreach($prd as $row){	
				$x = 1;
				}
				if($x == 0){
					?> 
					<div style="width: 85%; margin-top: 20px; margin-bottom: 135px;" align="left">
						<label class="emptyCart">Your cart is currently empty.</label> <br>
						<input type="button" class="returnShop" value="RETURN TO SHOP" onclick="location.href='products.php';">
					</div>
					<?php
				}else{
					$prixTotal = 0;
			?>
			<div align="right" class="cartDown">
					<table class="cartContent">
					<tr class="topRowCart">
						<td style="width: 10%;">
						</td>
						<td style="width: 22%;">	
						</td>
						<td style="width: 21%;">
							<label class="cartUppertitle">Product</label>
						</td>
						<td class="rowTh">
							<label class="cartUppertitle">Price</label>
						</td>
						<td class="rowTh">
							<label class="cartUppertitle">Quantity</label>
						</td>
						<td class="rowTh">
							<label class="cartUppertitle">Total</label>
						</td>
					</tr>
				<?php
				$prd = $produitCommande1C->recupererProduitsCommandesCourantParClient($idClient);
				foreach($prd as $row){	
					$refProd = $row['refProd'];
					$product = $produit1C->recupererProduit($refProd);
					foreach($product as $rowProd){
						$onSale = false; 
						$tx = 0;	
						if($eventActuel->rowCount() != 0){
							$eventActuel = $eventC->recupererEventByDate($date);
							foreach($eventActuel as $rowEvent){
								$remise = $remiseC->recupererRemise($rowProd['ref'], $rowEvent['id']);
								if($remise->rowCount() != 0){
									$onSale = true; 
									foreach($remise as $rowRemise){
										$tx = $rowRemise['taux'];
									}	
								}
							}
						}
						?>
					<tr>
						<td align="center">
							<form method="POST" action="crud/supprimerProduitCommande.php">
					            <input type="submit" name="supprimer" value="x" class="delete">
					            <input type="hidden" value="<?php echo $row['refProd']; ?>" name="refProd">
					            <input type="hidden" value="<?php echo $row['idCommande']; ?>" name="idCommande">
				            </form>
						</td>
						<td align="center">
							<img onclick="location.href='item.php?ref=<?php echo $row['refProd'];?>';" class="imgProdCom" src="../images/products/<?php echo $row['refProd'];?>/0.png" alt="imageProduit">
						</td>
						<td>
							<a href="item.php?ref=<?php echo $row['refProd'];?>" class="prodComName"><?php echo $rowProd['label'];?></label>
						</td>
						<td>
							<?php
								if($onSale){
							?>
								<label class="prixProdCom"><?php echo $rowProd['prix']*$tx/100;?> TND</label>
							<?php
								}else{
							?>
								<label class="prixProdCom"><?php echo $rowProd['prix'];?> TND</label>
							<?php
								}
							?>
						</td>
						<td>
							<form method="POST" action="crud/updateCommande.php">
								<input onchange="updateSwitch(<?php echo $row['refProd'];?>)" oninput="updateSwitch(<?php echo $row['refProd'];?>)" type="number" step="1" pattern="\d+" min="1" name="qte" value="<?php echo $row['qte'];?>" class="qteItem" style="background-color: white">
								<input type="submit" value="🗘" class="updateCartOFF" id="<?php echo $row['refProd'];?>" disabled>
								<input type="hidden" value="<?php echo $row['refProd'];?>" name="refProd">
								<input type="hidden" value="<?php echo $row['idCommande'];?>" name="idCommande">
							</form>
						</td>
						<td>
							<?php
								if($onSale){
									$prixTotal += (($tx*$rowProd['prix'])/100) * $row['qte'];
							?>
								<label class="prixProdCom"><?php echo (($tx*$rowProd['prix'])/100) * $row['qte'];?> TND</label>
							<?php
								}else{
									$prixTotal += $rowProd['prix'] * $row['qte'];
							?>
								<label class="prixProdCom"><?php echo $rowProd['prix'] * $row['qte'];?> TND</label>
							<?php
								}
							?>
						</td>
					</tr>	
					<?php } 
					}
					?>
					</table>
					<div class="divTotals">
						<table class="cartContent">
							<tr class="topRowCart">
								<td colspan="2">
									<label class="cartUppertitle" id="carttot">Cart totals</label>
								</td>
							</tr>
							<tr class="trMar">
								<td style="width: 38%">
									<label class="subtotal" style="margin-left: 8px">Subtotal</label>
								</td>
								<td>
									<label class="subtotal"><?php echo $prixTotal;?> TND</label>
								</td>
							</tr>
							<tr class="trMar">
								<td colspan="2" style="padding: 0">
									<table style="width: 100%; border: none" cellspacing="0" border="0">
										<tr style="border: none;">
											<td style="width: 38%; border: none;">
												<label class="subtotal" style="margin-left: 8px">Shipping</label>
											</td>
											<td style="border: none;">
												<label class="subtotal">5.00 TND</label>
											</td>
										</tr>
										<tr style="border: none;">
											<td style="border: none;">
											</td>
											<td style="border: none;">
												<label class="subtotal"> Shipping to </label><label class="subBolder"> Tunisia (TN).<label>
											</td>
										</tr>
									</table>
								</td>
							</tr>
							<tr class="trMar">
								<td style="width: 38%">
									<label class="subtotal" style="margin-left: 8px">Total</label>
								</td>
								<td>
									<label class="subBolder"> <?php echo $prixTotal + 5;?> TND</label>
								</td>
							</tr>
							<tr class="trMar">
								<td colspan="2">
									<input type="button" value="PROCEED TO CHECKOUT" class="checkoutBtn" onclick="location.href='checkout.php';">
								</td>
							</tr>
						</table>
					</div>       
					<?php 
						}
					?>
			</div>
		</div>
		<div class="prdBottomImg">
		</div>
		<script type="text/javascript">
			function updateSwitch(ref){
				document.getElementById(ref).type = "submit";
				document.getElementById(ref).className = "updateCart";
				document.getElementById(ref).disabled = false;
			}
		</script>
	</body>
</html>
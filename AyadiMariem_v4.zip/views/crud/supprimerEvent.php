<?PHP
	include "../core/EventC.php";
	$eventC = new EventC();
	if(isset($_POST["id"])){
		$eventC->supprimerEvent($_POST["id"]);
		header('Location: afficherEvent.php');
	}
?>
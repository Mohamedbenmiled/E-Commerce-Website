<?PHP
    include "../core/EventC.php";
    $event1C = new EventC();
    $listeEvent = $event1C->afficherEvents();
?>

<table border="1">
    <tr>
        <td>Id</td>
        <td>Nom</td>
        <td>Debut de evenement</td>
        <td>Fin de evenement</td>
        <td>Supprimer</td>
        <td>Modifier</td>
    </tr>
    <?php
    	foreach($listeEvent as $row){
    ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['nom']; ?></td>
        <td><?php echo $row['date_debut']; ?></td>
        <td><?php echo $row['date_fin']; ?></td>
        <td>
        	<form method="POST" action="supprimerEvent.php">
	            <input type="submit" name="supprimer" value="Supprimer">
	            <input type="hidden" value="<?php echo $row['id']; ?>" name="id">
            </form>
        </td>
        <td>
        	<a href="modifierEvent.php?id=<?php echo $row['id']; ?>">
            Modifier</a></td>
    </tr>
    <?php
    	}
    ?>
</table>
<?php
	include "../../config.php";
	include "../../entities/ProduitCommande.php";
	include "../../core/ProduitCommandeC.php";
	$produitCommandeC = new ProduitCommandeC();
	if(isset($_POST['qte']) && isset($_POST['refProd']) && isset($_POST['idCommande'])){
		$produitCommande = new ProduitCommande($_POST['refProd'], $_POST['idCommande'], $_POST['qte']);
		$produitCommandeC->modifierProduitCommande($produitCommande, $_POST['refProd'], $_POST['idCommande']);
	}
	header('Location: ../cart.php?success=true');
?>

<html>
	<head>
	</head>

	<body>
		<?php
			include "../entities/Livraison.php";
			include "../core/LivraisonC.php";
			if(isset($_GET['idCommande'])){
				$livraisonC = new LivraisonC();
			    $result = $livraisonC->recupererLivraison($_GET['idCommande']);
				foreach($result as $row){
					$idCommande = $row['idCommande'];
					$cinLivreur = $row['cinLivreur'];
					$etat = $row['etat'];
					$dateLivraison = $row['dateLivraison'];
		?>
		<form method="POST">
			<table>
				<caption>Modifier Livraison</caption>
				<tr>
					<td>Id Commande</td>
					<td><input type="number" name="idCommande" value="<?php echo $idCommande ?>"></td>
				</tr>
				<tr>
					<td>Cin Livreur</td>
					<td><input type="text" name="cinLivreur" value="<?php echo $cinLivreur ?>"></td>
				</tr>
				<tr>
					<td>Etat</td>
					<td><input type="number" name="etat" value="<?php echo $etat ?>"></td>
				</tr>
				<tr>
					<td>Date de Livraison</td>
					<td><input type="date" name="dateLivraison" value="<?php echo $dateLivraison ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="modifier" value="Modifier"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="hidden" name="idCommande_ini" value="<?php echo $_GET['idCommande'];?>"></td>
				</tr>
			</table>
		</form>
		<?php
				}
			}
			if(isset($_POST['modifier'])){
				$livraison = new Livraison($_POST['idCommande'], $_POST['cinLivreur'], $_POST['etat'], $_POST['dateLivraison']);
				$livraisonC->modifierLivraison($livraison, $_POST['idCommande_ini']);
				echo $_POST['idCommande_ini'];
				header('Location: afficherLivraison.php');
			}
		?>
	</body>
</html>
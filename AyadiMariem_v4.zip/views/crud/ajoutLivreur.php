<?php
	include "../../entities/Livreur.php";
	include "../../core/LivreurC.php";
	if(isset($_POST['cin']) and isset($_POST['mail']) and isset($_POST['nom']) and isset($_POST['prenom']) and isset($_POST['dateNaiss'])){
	$livreur1 = new Livreur($_POST['cin'], $_POST['mail'], $_POST['nom'], $_POST['prenom'], $_POST['dateNaiss']);
		$livreur1C = new LivreurC();
		$livreur1C->ajouterLivreur($livreur1);
		header('Location: afficherLivreur.php');	
	}else{
		echo "Verifier les champs";
	}
?>
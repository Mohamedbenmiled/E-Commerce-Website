<html>
	<head>
	</head>

	<body>
		<?php
			include "../entities/ProduitCommande.php";
			include "../core/ProduitCommandeC.php";
			if(isset($_GET['id'])){
				$produitCommandeC = new ProduitCommandeC();
			    $result = $produitCommandeC->recupererProduitCommande($_GET['id']);
				foreach($result as $row){
					$id = $row['id'];
					$refProd = $row['refProd'];
					$idClient = $row['idClient'];
					$qte = $row['qte'];
					$idPanier = $row['idPanier'];
					$date_a = $row['date_a'];
		?>
		<form method="POST">
			<table>
				<caption>Modifier Produit Commande</caption>
				<tr>
					<td>Id</td>
					<td><input type="number" name="id" value="<?php echo $id ?>"></td>
				</tr>
				<tr>
					<td>Reference Produit</td>
					<td><input type="number" name="refProd" value="<?php echo $refProd ?>"></td>
				</tr>
				<tr>
					<td>Id Client</td>
					<td><input type="number" name="idClient" value="<?php echo $idClient ?>"></td>
				</tr>
				<tr>
					<td>Quantite</td>
					<td><input type="number" name="qte" value="<?php echo $qte ?>"></td>
				</tr>
				<tr>
					<td>Id Panier</td>
					<td><input type="number" name="idPanier" value="<?php echo $idPanier ?>"></td>
				</tr>
				<tr>
					<td>Date d'Ajout</td>
					<td><input type="date" name="date_a" value="<?php echo $date_a ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="modifier" value="Modifier"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="hidden" name="id_ini" value="<?php echo $_GET['id'];?>"></td>
				</tr>
			</table>
		</form>
		<?PHP
				}
			}
			if(isset($_POST['modifier'])){
				$produitCommande = new ProduitCommande($_POST['id'], $_POST['refProd'], $_POST['idClient'], $_POST['qte'], $_POST['idPanier'], $_POST['date_a']);
				$produitCommandeC->modifierProduitCommande($produitCommande, $_POST['id_ini']);
				echo $_POST['id_ini'];
				header('Location: afficherProduitCommande.php');
			}
		?>
	</body>
</html>
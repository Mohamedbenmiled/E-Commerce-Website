<?PHP
    include "../../core/AvisC.php";
    $AvisC = new AvisC();
    $listeAvis = $AvisC->afficherAvis();
?>

<table border="1">
    <tr>
        <td>Refproduit</td>
        <td>Id Client</td>
        <td>Note</td>
        <td>Appreciation</td>
        <td>Date Avis</td>
        <td>Supprimer</td>
        <td>Modifier</td>
    </tr>
    <?php
    	foreach($listeAvis as $row){
    ?>
    <tr>
        <td><?php echo $row['refProduit']; ?></td>
        <td><?php echo $row['idClient']; ?></td>
        <td><?php echo $row['note']; ?></td>
        <td><?php echo $row['appreciation']; ?></td>
        <td><?php echo $row['dateAvis']; ?></td>
        <td>
        	<form method="POST" action="supprimerAvis.php">
	            <input type="submit" name="supprimer" value="Supprimer">
	            <input type="hidden" value="<?php echo $row['refProduit']; ?>" name="refproduit">
            </form>
        </td>
        <td>
        	<a href="modifierAvis.php?refproduit=<?php echo $row['refProduit']; ?>">
            Modifier</a></td>
    </tr>
    <?php
    	}
    ?>
</table>
<?PHP
	include "../../config.php";
	include "../../core/AvisC.php";
	$AvisC = new AvisC();
	if(isset($_POST["refproduit"]) AND isset($_POST["idClient"])){
		$AvisC->supprimerAvis($_POST["refproduit"], $_POST["idClient"]);
		include "../../entities/Produit.php";
		include "../../core/ProduitC.php";
		$Avis1C = new AvisC();
		$avis = $Avis1C->recupereravis($_POST['refproduit']);
		$total = $avis->rowCount();
		$noteMoy = 0;
		foreach($avis as $row){
			$noteMoy += $row['note'];
		}
		if($total == 0){
			$noteMoy = 0;
		}else{
			$noteMoy /= $total;
		}
		$produitC = new ProduitC();
		$produitC->updateNoteMoy($noteMoy, $_POST['refproduit']);
		$ref = $_POST["refproduit"];
		header("Location: ../item.php?ref=$ref");
	}
?>
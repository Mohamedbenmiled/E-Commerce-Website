<?php
	$idClient = 1;
	include "../config.php";
	include "../entities/ProduitCommande.php";
	include "../core/ProduitCommandeC.php";
	$produitCommande1C = new ProduitCommandeC();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Veni Vidi</title>
		<link rel="stylesheet" type="text/css" href="../stylesheet.css">
	</head>

	<body>
		<div class="topBar">
			<table style="width: 95%; height: 100%">
				<tr>
					<td style="width: 71%; padding-left: 5%">
						<a class="venividi" href="index.php">Veni Vidi</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="index.php">Home</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="about.php">About</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="contact.php">Contact</a>
					</td>
					<td style="width: 6%" class="choixTd">
						<a class="choix" href="products.php">Shop</a>
					</td>
					<td style="width: 6%">
						<a class="choix" href="cart.php">
							<img src="../images/cart.png" alt="Cart" class="cart">
							<?php
								$nb = $produitCommande1C->getCartNbForClient($idClient);
							?>
							<label class="cartNb"><?php echo $nb;?></label>
						</a>
					</td>
				</tr>		
			</table>	
		</div>
		<div class="aboutFirst" align="center"><br><br><br><br><br><br><br><br><br>
			<label class="aboutTitle">ABOUT US</label>
			<p class="aboutText">We are Veni Vidi. We are an empowering, bold and forward thinking online fashion brand, inspired by real life. We design and create product informed by you, our customers, our friends and global influences: Catwalk, celebrity, social media, bloggers and street style, creating an online fashion destination that encompasses and celebrates everything it means to be a modern citizen in a digitally immersed world today.</p>
		</div>	
		<div class="about2" align="center">
			<label class="s1">MEET OUR TEAM</label>
			<table class="tableTeam">
				<tr>	
					<td id="tableSpace">
						<img src="../images/habib.jpg" alt="habib" class="teamImage"><br><br>
						<label class="teamName">HABIB MAJOUL</label>
					</td>
					<td id="tableSpace">
						<img src="../images/mariem.jpg" alt="mariem" class="teamImage"><br><br>
						<label class="teamName">MARIEM AYADI</label>
					</td>
					<td>
						<img src="../images/wissem.jpg" alt="wissem" class="teamImage"><br><br>
						<label class="teamName">WISSEM LAHBIB</label>
					</td>
				</tr>
				<tr>	
					<td id="tableSpace">
						<img src="../images/aziz.jpg" alt="aziz" class="teamImage"><br><br>
						<label class="teamName">AZIZ MRABET</label>
					</td>
					<td id="tableSpace">
						<img src="../images/mohamed.jpg" alt="mohamed" class="teamImage"><br><br>
						<label class="teamName">MOHAMED BEN MILED</label>
					</td>
					<td>
						<img src="../images/dhafer.jpg" alt="dhafer" class="teamImage"><br><br>
						<label class="teamName">DHAFER SLIMI</label>
					</td>
				</tr>		
			</table>
			<div class="aboutBottom">
			</div>
			<div class="fourth">
			</div>
		</div>
		<div class="preFooter">
		</div>
		<div class="footer">
		</div>
	</body>
</html>
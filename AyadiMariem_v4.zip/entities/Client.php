<?php
	class Client{
		private $id;
		private $mail;
		private $nom;
		private $prenom;
		private $dateNaiss;
		private $adresse;
		private $dateInsc;
		function __construct($id, $mail, $nom, $prenom, $dateNaiss, $adresse, $dateInsc){
			$this->id = $id;
			$this->mail = $mail;
			$this->nom = $nom;
			$this->prenom = $prenom;
			$this->dateNaiss = $dateNaiss;
			$this->adresse = $adresse;
			$this->dateInsc = $dateInsc;
		}
		function getId(){
			return $this->id;
		}
		function getMail(){
			return $this->mail;
		}
		function getNom(){
			return $this->nom;
		}
		function getPrenom(){
			return $this->prenom;
		}
		function getDateNaiss(){
			return $this->dateNaiss;
		}
		function getAdresse(){
			return $this->adresse;
		}
		function getDateInsc(){
			return $this->dateInsc;
		}
		function setId($id){
			$this->id = $id;
		}
		function setMail($mail){
			$this->mail = $mail;
		}
		function setNom($nom){
			$this->nom = $nom;
		}
		function setPrenom($prenom){
			$this->prenom = $prenom;
		}
		function setDateNaiss($dateNaiss){
			$this->dateNaiss = $dateNaiss;
		}
		function setAdresse($adresse){
			$this->adresse = $adresse;
		}
		function setDateInsc($dateInsc){
			$this->dateInsc = $dateInsc;
		}
	}
?>
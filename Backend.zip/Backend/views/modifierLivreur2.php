        <?php
        include "../entities/Livreur.php";
        include "../core/LivreurC.php";
        $livreurC = new LivreurC();
          if($_POST['verifMod'] == true){
    				$livreur = new Livreur($_POST['cin'], $_POST['mail'], $_POST['nom'], $_POST['prenom'], $_POST['dateNaiss']);
    				$livreurC->modifierLivreur($livreur, $_POST['cin_ini']);
    				header('Location: dataLivreurs.php');
			    }else{
            $c = $_POST['cin_ini'];
            header('Location: modifierLivreur.php?cin=$c');
          }
		    ?>

<html>
	<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Veni Vidi | Modification Page</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="../plugins/fontawesome-free/css/all.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
    <!-- icheck bootstrap -->
    <link rel="stylesheet" href="../plugins/icheck-bootstrap/icheck-bootstrap.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../dist/css/adminlte.min.css">
    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
	</head>

	<body class="hold-transition register-page">
  <div class="register-box">
    <div class="register-logo">
      <a href="../index2.html"><b>Veni</b>Vidi</a>
    </div>
    <div class="card">
      <div class="card-body register-card-body">
        <p class="login-box-msg">Modifier Livraison</p>
		<?php
      include("../core/CommandeC.php");
      include("../entities/Commande.php");
      include("../config.php");
			include "../entities/Livraison.php";
			include "../core/LivraisonC.php";
      include("../core/LivreurC.php");
      include("../entities/Livreur.php");
			if(isset($_GET['idCommande'])){
				$livraisonC = new LivraisonC();
			    $result = $livraisonC->recupererLivraison($_GET['idCommande']);
				foreach($result as $row){
					$idCommande = $row['idCommande'];
					$cinLivreur = $row['cinLivreur'];
					$etat = $row['etat'];
					$dateLivraison = $row['dateLivraison'];
		?>
		<form method="POST">
			<table>

        <div class="input-group mb-3">
          <select id ="id1" name="idCommande" style="width: 180px">
            <?php 
            $livraisonC = new LivraisonC();
            $commandeC = new CommandeC();
              $com = $commandeC->afficherCommandes();
              echo $com->rowCount();
              $add = 1;
              $none = 1;
              if($com->rowCount() == 0){   
                $add = 0;
            ?>
              <option value="0" style="font-style: italic;">Aucune commande</option>
          </select>
            <?php
            }else{
              foreach($com as $rowCom){
                $liv = $livraisonC->recupererLivraison($rowCom['id']);
                foreach($liv as $rowLiv){
            ?>
            <option value="<?php echo $rowCom['id'];?>" <?php if($rowCom['id'] == $_GET['idCommande']){echo "selected";}if($liv->rowCount() != 0 && $rowLiv['idCommande'] != $_GET['idCommande']){echo " disabled";}?>>Commande N°<?php echo $rowCom['id'];?></option>
            <?php
              }
              }
            ?>
          </select>
          <?php 
            }
          ?>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>

        <div class="input-group mb-3">
          <select id ="cin" name="cinLivreur" style="width: 179px">
            <?php 
              $livreurC = new LivreurC();
              $livreurs = $livreurC->afficherLivreurs();
              if($livreurs->rowCount() == 0){
                $add = 0;
                ?>
                  <option value="0" style="font-style: italic;">Aucun livreur</option>
              </select>
                <?php
                }else{
                  foreach($livreurs as $rowLiv){
                ?>
                <option value="<?php echo $rowLiv['cin'];?>" <?php if($rowLiv['cin']==$cinLivreur){echo "selected";}?>><?php echo $rowLiv['prenom']." ".$rowLiv['nom'];?></option>
                <?php
                  }
                ?>
              </select>
              <?php 
                }
              ?>
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>

        <div class="input-group mb-3">
          <select id="etat" name="etat" style="width: 179px">
            <option value="0" <?php if(0==$etat){echo "selected";}?>>Etat - En attente</option>
            <option value="1" <?php if(1==$etat){echo "selected";}?>>Etat - En cours</option>
            <option value="2" <?php if(2==$etat){echo "selected";}?>>Etat - Livré</option>
          </select> 
          <div class="input-group-append">
            <div class="input-group-text">
              <span class="fas fa-user"></span>
            </div>
          </div>
        </div>
        <div class="col-4">
          <input class="btn btn-primary btn-block" type="submit" name="modifier" value="Modifier">
        </div>
				<tr>
					<td></td>
					<td><input type="hidden" name="idCommande_ini" value="<?php echo $_GET['idCommande'];?>"></td>
				</tr>
			</table>
		</form>
		<?php
				}
			}
			if(isset($_POST['modifier'])){
		        $date = NULL;
		        if($_POST['etat'] == 2){
		          $date = date("Y/m/d H:i:s");
		        }
				$livraison = new Livraison($_POST['idCommande'], $_POST['cinLivreur'], $_POST['etat'], $date);
				$livraisonC->modifierLivraison($livraison, $_POST['idCommande_ini']); 
		        $headers = 'From: habib.majoul@esprit.tn' . "\r\n" . 
		           'MIME-Version: 1.0' . "\r\n" .
		           'Content-Type: text/html; charset=utf-8';
		        switch($_POST['etat']){
		        	case 0: 
		        		$etatM = "en attente de livraison";
		        		break;
		        	case 1:
		        		$etatM = "en cours de livraison";
		        		break;
		        	case 2:
		        		$etatM = "livrée";
		        		break;
		        }
		        $text = "La commande N°".$_POST['idCommande']." est ".$etatM." à ".date("Y/m/d H:i:s");
				$result = mail("mariem.ayadi@esprit.tn", "VENI VIDI - Livraisons", $text, $headers);
				var_dump($result);
				echo $_POST['idCommande_ini'];
				header('Location: dataLivraisons.php');
			}
		?>
      </div>
    </div>
  </div>

	</body>
</html>

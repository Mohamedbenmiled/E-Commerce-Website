<?php
	include "../config.php";
	include "../entities/Livraison.php";
	include "../core/LivraisonC.php";
	if($_POST['etat'] == 2){
        $date = date("Y/m/d H:i:s");
    }
	$livraison1 = new Livraison($_POST['idCommande'], $_POST['cinLivreur'], $_POST['etat'], $date);
	$livraison1C = new LivraisonC();
	$livraison1C->ajouterLivraison($livraison1);
	header('Location: dataLivraisons.php');
?>

<?php
	class Livraison{
		private $idCommande;
		private $cinLivreur;
		private $etat;
		private $dateLivraison;
		function __construct($idCommande, $cinLivreur, $etat, $dateLivraison){
			$this->idCommande = $idCommande;
			$this->cinLivreur = $cinLivreur;
			$this->etat = $etat;
			$this->dateLivraison = $dateLivraison;
		}
		function getIdCommande(){
			return $this->idCommande;
		}
		function getCinLivreur(){
			return $this->cinLivreur;
		}
		function getEtat(){
			return $this->etat;
		}
		function getDateLivraison(){
			return $this->dateLivraison;
		}
		function setIdCommande($cin){
			$this->idCommande = $idCommande;
		}
		function setCinLivreur($cinLivreur){
			$this->cinLivreur = $cinLivreur;
		}
		function setEtat($etat){
			$this->etat = $etat;
		} 
		function setDateLivraison($dateLivraison){
			$this->dateLivraison = $dateLivraison;
		}
	}
?>
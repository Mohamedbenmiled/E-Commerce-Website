<?php
	class Reclamation{
		private $id;
		private $idClient;
		private $sujet;
		private $message;
		function __construct($id, $idClient, $sujet, $message){
			$this->id = $id;
			$this->idClient= $idClient;
			$this->sujet = $sujet;
			$this->message = $message;
		}
		function getid(){
			return $this->id;
		}
		function getidClient(){
			return $this->idClient;
		}
		function getsujet(){
			return $this->sujet;
		}
		function getmessage(){
			return $this->message;
		}
		
		function setid($id){
			$this->id = $id;
		}
		function setidClient($idClient){
			$this->idClient = $idClient;
		}
		function setsujet($sujet){
			$this->sujet = $sujet;
		}
		function setmessage($message){
			$this->message = $message;
		}
		
	}
?>
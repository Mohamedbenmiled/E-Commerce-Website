<?php
	//include "../config.php";
	class ReclamationC{
		function afficherReclamation($Reclamation){
			echo "id: ".$Reclamation->getid()."<br>";
			echo "idclient: ".$Reclamation->getidClient()."<br>";
			echo "sujet: ".$Reclamation->getsujet()."<br>";
			echo "message: ".$Reclamation->getmessage()."<br>";
		}

		function ajouterReclamation($Reclamation){
			$sql = "INSERT INTO Reclamation(id, idClient, sujet, message) values(:id, :idClient, :sujet, :message)";
			$db = config::getConnexion();
			try{
		       	$req = $db->prepare($sql);
		       	$id = $Reclamation->getid();
		       	$idClient = $Reclamation->getidClient();
		        $sujet = $Reclamation->getsujet();
		        $message = $Reclamation->getmessage();
		        $req->bindValue(':id', $id);
		        $req->bindValue(':idClient', $idClient);
				$req->bindValue(':sujet', $sujet);
				$req->bindValue(':message', $message);
				$req->execute(); 
		    }catch(Exception $e){
		        echo 'Erreur: '.$e->getMessage();
		    }
		}
		function afficherReclamations(){
			$sql = "SELECT * FROM Reclamation";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }	
		}
		function supprimerReclamation($id){
			$sql = "DELETE FROM Reclamation where id = :id";
			$db = config::getConnexion();
		    $req = $db->prepare($sql);
			$req->bindValue(':id', $id);
			try{
		        $req->execute();
		    }catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function modifierReclamation($Reclamation, $id){
			$sql = "UPDATE Reclamation SET id = :idNew, idClient = :idClient, sujet = :sujet, message = :message WHERE id = :id";
			$db = config::getConnexion();
			try{
		        $req = $db->prepare($sql);
				$idNew = $Reclamation->getid();
				$idClient = $Reclamation->getidClient();
		        $sujet = $Reclamation->getsujet();
		        $message = $Reclamation->getmessage();
		        $datas = array(':idNew' => $idNew, ':id' => $id, ':idClient' => $idClient, ':sujet' => $sujet, ':message' => $message);
		        $req->bindValue(':idNew', $idNew);
				$req->bindValue(':id', $id);
				$req->bindValue(':idClient', $idClient);
				$req->bindValue(':sujet', $sujet);
				$req->bindValue(':message', $message);
		        $s = $req->execute();
		    }catch(Exception $e){
		        echo " Erreur ! ".$e->getMessage();
		   		echo " Les datas : " ;
		  		print_r($datas);
		    }	
		}
		function recupererReclamation($id){
			$sql = "SELECT * FROM Reclamation where id = $id";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
	}
?>
<?php
	//include "../config.php";
	class EventC{
		function afficherEvent($event){
			echo "Id_E: ".$event->getId_E()."<br>";
			echo "Nom: ".$event->getNom()."<br>";
			echo "Debut de l'event: ".$event->getDate_dbt()."<br>";
			echo "Fin de l'event: ".$event->getDate_fin()."<br>";	
		}
		function ajouterEvent($event){
			$sql = "INSERT INTO Evenements(id, nom, date_debut, date_fin) values(:Id_E, :nom, :date_dbt, :date_fin)";
			$db = config::getConnexion();
			try{
		       	$req = $db->prepare($sql);
		       	$Id_E = $event->getId_E();
		        $nom = $event->getNom();
		        $date_dbt = $event->getDate_dbt();
		        $date_fin = $event->getDate_fin();
		        $req->bindValue(':Id_E', $Id_E);
				$req->bindValue(':nom', $nom);
				$req->bindValue(':date_dbt', $date_dbt);
				$req->bindValue(':date_fin', $date_fin);
		        $req->execute(); 
		    }catch(Exception $e){
		        echo 'Erreur: '.$e->getMessage();
		    }
		}
		function afficherEvents(){
			$sql = "SELECT * FROM Evenements";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }	
		}
		function supprimerEvent($id){
			$sql = "DELETE FROM Evenements where id = :id";
			$db = config::getConnexion();
		    $req = $db->prepare($sql);
			$req->bindValue(':id', $id);
			try{
		        $req->execute();
		    }catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function modifierEvent($event, $id){
			$sql = "UPDATE Evenements SET id = :Id_ENew, nom = :nom, date_debut = :date_dbt, date_fin = :date_fin WHERE id = :id";
			$db = config::getConnexion();
			try{
		        $req = $db->prepare($sql);
				$Id_ENew = $event->getId_E();
		        $nom = $event->getNom();
		        $date_dbt = $event->getDate_dbt();
		        $date_fin = $event->getDate_fin();
				$datas = array(':Id_ENew' => $Id_ENew, ':nom'=>$nom, ':date_dbt' => $date_dbt, ':date_fin'=>$date_fin);
				$req->bindValue(':Id_ENew', $Id_ENew);
				$req->bindValue(':nom', $nom);
				$req->bindValue(':date_dbt', $date_dbt);
				$req->bindValue(':date_fin', $date_fin);
				$req->bindValue(':id', $id);
		        $s = $req->execute();
		    }catch(Exception $e){
		        echo " Erreur ! ".$e->getMessage();
		   		echo " Les datas : " ;
		  		print_r($datas);
		    }	
		}
		function recupererEvent($Id_E){
			$sql = "SELECT * FROM Evenements WHERE id = $Id_E";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function recupererEventByDate($date){
			$sql = "SELECT * FROM Evenements WHERE '".$date."' BETWEEN date_debut AND date_fin";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
	}
?>
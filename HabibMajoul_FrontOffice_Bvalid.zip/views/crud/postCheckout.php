<?php
	include "../../config.php";
	include "../../entities/Livraison.php";
	include "../../core/LivraisonC.php";
	include "../../entities/Livreur.php";
	include "../../core/LivreurC.php";
	include "../../entities/Commande.php";
	include "../../core/CommandeC.php";
	include "../../entities/Client.php";
	include "../../core/ClientC.php";
	include "../../entities/ProduitCommande.php";
	include "../../core/ProduitCommandeC.php";
	include "../../entities/Produit.php";
	include "../../core/ProduitC.php";
	include "../../entities/Event.php";
	include "../../core/EventC.php";
	include "../../entities/Remise.php";
	include "../../core/RemiseC.php";
	$livreurC = new LivreurC();
	$livraisonC = new LivraisonC();
	$livraisonC = new LivraisonC();
	$commandeC = new CommandeC();
	$clientC = new ClientC();
	$produitC = new ProduitC();
	$remiseC = new RemiseC();
	$eventC = new EventC();
	$produitCommandeC = new ProduitCommandeC();

	if(isset($_POST['idCommande'])){
		$cinLiv = $livreurC->livreurDispo();
		$livraison = new Livraison($_POST['idCommande'], $cinLiv, 0, NULL);
		$livraisonC->ajouterLivraison($livraison);
		$idClient = $commandeC->recupererIdClientParIdCommandeEtEtat($_POST['idCommande']);
		
		$nbCart = $produitCommandeC->getCartNbForClient($idClient);
		$commande = new Commande($idClient, 0, date('Y-m-d H:i:s'));
		$commandeC->modifierCommande($commande, $_POST['idCommande']);
		$headers = 'From: venividi.noreply@gmail.com' . "\r\n" . 
		      'MIME-Version: 1.0' . "\r\n" .
		      'Content-Type: text/html; charset=utf-8';
		$text = "Vous avez placé une commande<br>Commande N°".$_POST['idCommande']." à ".date("Y/m/d H:i:s")."<br>
		Nombre de produits commandés: ".$nbCart."<br><br>";
		$listePC = $produitCommandeC->recupererProduitCommandeParCommande($_POST['idCommande']);
		$date = date("Y/m/d H:i:s");
		$eventActuel = $eventC->recupererEventByDate($date);
		$total = 0;
		foreach($listePC as $row){
			$prixTotal = 0;
			$refProd = $row['refProd'];
			$product = $produitC->recupererProduit($refProd);
			foreach($product as $rowProd){
				$onSale = false; 
				$tx = 0;	
				if($eventActuel->rowCount() != 0){
					$eventActuel = $eventC->recupererEventByDate($date);
					foreach($eventActuel as $rowEvent){
						$remise = $remiseC->recupererRemise($rowProd['ref'], $rowEvent['id']);
						if($remise->rowCount() != 0){
							$onSale = true; 
							foreach($remise as $rowRemise){
								$tx = $rowRemise['taux'];
							}	
						}
					}
				}
			}
			$prix = 0;
			if($onSale == true){
				$prix = $rowProd['prix'] * $tx / 100;
			}else{
				$prix = $rowProd['prix'];
			}
			$prixTotal += $prix * $row['qte'];
			$total += $prixTotal;
			$text = $text."    ".$rowProd['label']."    ".$prix." TND    x".$row['qte']."    = ".$prixTotal." TND<br>";
		}
		$text = $text."<br>Total: ".$total." TND<br>";
		$result = mail($clientC->recupererMail($idClient), "VENI VIDI - Commande N°".$commandeC->nbProduits($_POST['idCommande']), $text, $headers);
		var_dump($result);
		header("Location: ../orders.php");
	}else{
		echo "Verifier les champs";
	}
?>
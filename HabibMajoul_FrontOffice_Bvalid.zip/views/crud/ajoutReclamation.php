<?php
	include "../../config.php";
	include "../../entities/Reclamation.php";
	include "../../core/ReclamationC.php";
	include "../../entities/Client.php";
	include "../../core/ClientC.php";
	$clientC = new ClientC();
	if (isset($_POST['idclient']) and isset($_POST['subject']) and isset($_POST['message'])){
	$rec1 = new Reclamation($_POST['idclient'],$_POST['idclient'], $_POST['subject'], $_POST['message']);
		$rec1C = new ReclamationC();
		$rec1C->ajouterReclamation($rec1);
		$mailClient = $clientC->recupererMail($_POST['idclient']);
		$headers = 'From: $mailClient' . "\r\n" . 
		      'MIME-Version: 1.0' . "\r\n" .
		      'Content-Type: text/html; charset=utf-8';
		$np = $clientC->recupererNomPrenom($_POST['idclient']);
		$text = "Email sent by ".$np."<br>"."Mail Adress : ".$mailClient." <br>".$_POST['message'];
		$subject = $_POST['subject'];
		switch($subject){
			case 0:
				$sb = 'Appreciation';
				break;
			case 1:
				$sb = 'Information';
				break;
			case 2:
				$sb = 'Request';
				break;
			case 3:
				$sb = 'Delivery';
				break;
			case 4:
				$sb = 'Other';
				break;
		}
		$result = mail("venividi.noreply@gmail.com", "VENI VIDI - $sb", $text, $headers);
		var_dump($result);
		header('Location: ../contact.php?success=true#s');	
	}else{
		echo "Verifier les champs";
	}
?>
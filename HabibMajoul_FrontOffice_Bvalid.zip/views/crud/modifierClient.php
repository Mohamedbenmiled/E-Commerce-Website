<html>
	<head>
	</head>

	<body>
		<?php
			include "../../entities/Client.php";
			include "../../core/ClientC.php";
			if(isset($_GET['id'])){
				$clientC = new ClientC();
			    $result = $clientC->recupererClient($_GET['id']);
				foreach($result as $row){
					$id = $row['id'];
					$mail = $row['mail'];
					$nom = $row['nom'];
					$prenom = $row['prenom'];
					$dateNaiss = $row['dateNaiss'];
					$adresse = $row['adresse'];
					$dateInsc = $row['dateInsc'];
		?>
		<form method="POST">
			<table>
				<caption>Modifier Client</caption>
				<tr>
					<td>Id</td>
					<td><input type="number" name="id" value="<?php echo $id ?>"></td>
				</tr>
				<tr>
					<td>Mail</td>
					<td><input type="mail" name="mail" value="<?php echo $mail ?>"></td>
				</tr>
				<tr>
					<td>Nom</td>
					<td><input type="text" name="nom" value="<?php echo $nom ?>"></td>
				</tr>
				<tr>
					<td>Prenom</td>
					<td><input type="text" name="prenom" value="<?php echo $prenom ?>"></td>
				</tr>
				<tr>
					<td>Date de Naissance</td>
					<td><input type="date" name="dateNaiss" value="<?php echo $dateNaiss ?>"></td>
				</tr>
				<tr>
					<td>Adresse</td>
					<td><input type="text" name="adresse" value="<?php echo $adresse ?>"></td>
				</tr>
				<tr>
					<td>Date d'Inscription</td>
					<td><input type="text" name="dateInsc" value="<?php echo $dateInsc ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="modifier" value="Modifier"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="hidden" name="id_ini" value="<?php echo $_GET['id'];?>"></td>
				</tr>
			</table>
		</form>
		<?PHP
				}
			}
			if(isset($_POST['modifier'])){
				$client = new Client($_POST['id'], $_POST['mail'], $_POST['nom'], $_POST['prenom'], $_POST['dateNaiss'], $_POST['adresse'], $_POST['dateInsc']);
				$clientC->modifierClient($client, $_POST['id_ini']);
				echo $_POST['id_ini'];
				header('Location: afficherClient.php');
			}
		?>
	</body>
</html>
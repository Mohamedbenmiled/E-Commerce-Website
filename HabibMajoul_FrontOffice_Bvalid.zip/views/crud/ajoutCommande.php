<?php
	include "../../entities/Commande.php";
	include "../../core/CommandeC.php";
	if(isset($_POST['id']) and isset($_POST['prixTotal'])){
		$commande1 = new Commande($_POST['id'], $_POST['prixTotal']);
		$commande1C = new CommandeC();
		$commande1C->ajouterCommande($commande1);
		header('Location: afficherCommande.php');	
	}else{
		echo "Verifier les champs";
	}
?>
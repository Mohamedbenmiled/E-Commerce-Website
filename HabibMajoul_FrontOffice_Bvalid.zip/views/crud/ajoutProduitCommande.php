<?php
	include "../../config.php";
	include "../../entities/ProduitCommande.php";
	include "../../core/ProduitCommandeC.php";
	include "../../entities/Commande.php";
	include "../../core/CommandeC.php";
	$commande1C = new CommandeC();
	$produitCommande1C = new ProduitCommandeC();
	if(isset($_POST['idClient']) and isset($_POST['qte']) and isset($_POST['refProd'])){
		$idClient = $_POST['idClient'];
		$qte = $_POST['qte'];
		$refProd = $_POST['refProd'];
		$idCommande = $commande1C->recupererIdParClientEtEtat($idClient);
		if($idCommande != -1){
			$prodExist = $produitCommande1C->recupererProduitCommande($refProd, $idCommande);
			if($prodExist->rowCount() != 0){
				$oldQte = 0;
				foreach($prodExist as $rowProdExist){
					$oldQte = $rowProdExist['qte'];
				}
				$produitCommande = new ProduitCommande($refProd, $idCommande, $qte + $oldQte);
				$produitCommande1C->modifierProduitCommande($produitCommande, $refProd, $idCommande);
			}else{
				$produitCommande = new ProduitCommande($refProd, $idCommande, $qte);
				$produitCommande1C->ajouterProduitCommande($produitCommande);
			}		
		}else{
			$commande = new Commande($idClient, 1, NULL);
			$commande1C->ajouterCommande($commande);
			$idCommande = $commande1C->recupererIdParClientEtEtat($idClient);
			$produitCommande = new ProduitCommande($refProd, $idCommande, $qte);
			$produitCommande1C->ajouterProduitCommande($produitCommande);
		}
		header("Location: ../item.php?ref=$refProd&success=true");
	}else{
		echo "Erreur d'ajout de commande";
		header("Location: ../item.php?ref=$refProd&success=false");
	}
?>
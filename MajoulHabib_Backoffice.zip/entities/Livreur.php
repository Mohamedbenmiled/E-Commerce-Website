<?php
	class Livreur{
		private $cin;
		private $mail;
		private $nom;
		private $prenom;
		private $dateNaiss;
		function __construct($cin, $mail, $nom, $prenom, $dateNaiss){
			$this->cin = $cin;
			$this->mail = $mail;
			$this->nom = $nom;
			$this->prenom = $prenom;
			$this->dateNaiss = $dateNaiss;
		}
		function getCin(){
			return $this->cin;
		}
		function getMail(){
			return $this->mail;
		}
		function getNom(){
			return $this->nom;
		}
		function getPrenom(){
			return $this->prenom;
		}
		function getDateNaiss(){
			return $this->dateNaiss;
		}
		function setCin($cin){
			$this->cin = $cin;
		}
		function setMail($mail){
			$this->mail = $mail;
		}
		function setNom($nom){
			$this->nom = $nom;
		} 
		function setPrenom($prenom){
			$this->prenom = $prenom;
		}
		function setDateNaiss($dateNaiss){
			$this->dateNaiss = $dateNaiss;
		}
	}
?>
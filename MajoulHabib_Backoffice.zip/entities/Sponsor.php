<?php
	class Sponsor{

		private $nom;
		private $adresse;
		private $type;
		private $budget;
		function __construct($nom,$adresse, $type,$budget){

			$this->nom = $nom;
			$this->adresse = $adresse;
			$this->type = $type;
			$this->budget= $budget;
		}


		function getNom(){
			return $this->nom;
		}

		function getAdresse(){
			return $this->adresse;
		}
		function getType(){
			return $this->type;
		}
		function getBudget(){
            return $this->budget;
        }


		function setNom($nom){
			$this->nom = $nom;
		}
		function setAdresse($adresse){
            $this->adresse = $adresse;
        }
		function setType($type){
			$this->type = $type;
		}

		function setBudget($budget){
			$this->budget= $budget;
		}
	}
?>
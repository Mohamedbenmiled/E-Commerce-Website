
function verif(){
  var valid = true;

  var letters = /^[a-zA-Z]+[a-zA-Z]+$/;
  var nom = document.getElementById("nom").value;
  if(letters.test(nom) == false){
    document.getElementById("nom").value = '';
    document.getElementById("nom").focus();
    document.getElementById("nom").placeholder = "NOM Invalide";
    valid = false;
  }



  if(!valid){
    return false;
  }
  document.getElementById("form").submit();
  return true;
}

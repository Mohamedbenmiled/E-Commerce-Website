
function verif(){
  var valid = true;

  var cin = document.getElementById("cin").value;
  if((cin.length != 8) || (isNaN(cin))){
    document.getElementById("cin").value = '';
    document.getElementById("cin").focus();
    document.getElementById("cin").placeholder = "CIN Invalide";
    valid = false;
  }
  var etat = document.getElementById("etat").value;
  if(etat !=1 && etat !=0){
    document.getElementById("etat").value = '';
    document.getElementById("etat").focus();
    document.getElementById("etat").placeholder = "ETAT Invalide";
    valid = false;
  }

  if(!valid){
    return false;
  }
  document.getElementById("form").submit();
  return true;
}

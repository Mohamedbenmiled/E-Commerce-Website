<?php
	class ProduitCommande{
		private $id;
		private $refProd;
		private $idClient;
		private $qte;
		private $idPanier;
		private $date_a;
		function __construct($id, $refProd, $idClient, $qte, $idPanier, $date_a){
			$this->id = $id;
			$this->refProd = $refProd;
			$this->idClient = $idClient;
			$this->qte = $qte;
			$this->idPanier = $idPanier;
			$this->date_a = $date_a;
		}
		function getId(){
			return $this->id;
		}
		function getRefProd(){
			return $this->refProd;
		}
		function getIdClient(){
			return $this->idClient;
		}
		function getQte(){
			return $this->qte;
		}
		function getIdPanier(){
			return $this->idPanier;
		}
		function getDate_a(){
			return $this->date_a;
		}
		function setId($id){
			$this->id = $id;
		}
		function setRefProd($refProd){
			$this->refProd = $refProd;
		}
		function setIdClient($idClient){
			$this->idClient = $idClient;
		}
		function setQte($qte){
			$this->qte = $qte;
		}
		function setIdPanier($idPanier){
			$this->idPanier = $idPanier;
		}
		function setDate_a($date_a){
			$this->date_a = $date_a;
		}
	}
?>
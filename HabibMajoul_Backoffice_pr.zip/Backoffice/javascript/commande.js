

function verif(){
  var valid = true;


  var idClient = document.getElementById("idClient").value;
  if(idClient==""){
    document.getElementById("idClient").value = '';
    document.getElementById("idClient").focus();
    document.getElementById("idClient").placeholder = "ID CLIENT Invalide";
    valid = false;
  }
  var etat = document.getElementById("etat").value;
  if(etat == ""){
    document.getElementById("etat").value = '';
    document.getElementById("etat").focus();
    document.getElementById("etat").placeholder = "ETAT Invalide";
    valid = false;
  }



  if(!valid){
    return false;
  }
  $("#notify-button").click(function(){
    Push.create("Hello world!",{
      body: "This is example of Push.js Tutorial",
      icon: '/Logo_small.png',
      timeout: 2000,
      onClick: function () {
        window.focus();
        this.close();
      }
    });
  });
  document.getElementById("form").submit();
  return true;
}

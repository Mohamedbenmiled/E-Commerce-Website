<?php
	//include "../config.php";
	class LivraisonC{
		function afficherLivraison($livraison){
			echo "Id Commande: ".$livraison->getIdCommande()."<br>";
			echo "Cin Livreur: ".$livraison->getCinLivreur()."<br>";
			echo "Etat: ".$livraison->getEtat()."<br>";
			echo "Date Livraison: ".$livraison->getDateLivraison()."<br>";
		}
		function ajouterLivraison($livraison){
			$sql = "INSERT INTO Livraison(idCommande, cinLivreur, etat, dateLivraison) values(:idCommande, :cinLivreur, :etat, :dateLivraison)";
			$db = config::getConnexion();
			try{
		       	$req = $db->prepare($sql);
		       	$idCommande = $livraison->getIdCommande();
		       	$cinLivreur = $livraison->getCinLivreur();
		        $etat = $livraison->getEtat();
		        $dateLivraison = $livraison->getDateLivraison();
		        $req->bindValue(':idCommande', $idCommande);
		        $req->bindValue(':cinLivreur', $cinLivreur);
				$req->bindValue(':etat', $etat);
				$req->bindValue(':dateLivraison', $dateLivraison);
		        $req->execute(); 
		    }catch(Exception $e){
		        echo 'Erreur: '.$e->getMessage();
		    }
		}
		function afficherLivraisons(){
			$sql = "SELECT * FROM Livraison";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }	
		}
		function supprimerLivraison($idCommande){
			include("../config.php");
			$sql = "DELETE FROM Livraison WHERE idCommande = :idCommande";
			$db = config::getConnexion();
		    $req = $db->prepare($sql);
			$req->bindValue(':idCommande', $idCommande);
			try{
		        $req->execute();
		    }catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function modifierLivraison($livraison, $idCommande){
			$sql = "UPDATE Livraison SET idCommande = :idCommandeNew, cinLivreur = :cinLivreur, etat = :etat, dateLivraison = :dateLivraison WHERE idCommande = :idCommande";
			$db = config::getConnexion();
			try{
		        $req = $db->prepare($sql);
				$idCommandeNew = $livraison->getIdCommande();
				$cinLivreur = $livraison->getCinLivreur();
		        $etat = $livraison->getEtat();
		        $dateLivraison = $livraison->getDateLivraison();
				$datas = array(':idCommandeNew' => $idCommandeNew, ':cinLivreur' => $cinLivreur, ':etat'=>$etat, ':dateLivraison'=>$dateLivraison, ':idCommande' => $idCommande);
				$req->bindValue(':idCommandeNew', $idCommandeNew);
				$req->bindValue(':cinLivreur', $cinLivreur);
				$req->bindValue(':etat', $etat);
				$req->bindValue(':dateLivraison', $dateLivraison);
				$req->bindValue(':idCommande', $idCommande);
		        $s = $req->execute();
		    }catch(Exception $e){
		        echo " Erreur ! ".$e->getMessage();
		   		echo " Les datas : " ;
		  		print_r($datas);
		    }	
		}
		function recupererLivraison($idCommande){
			$sql = "SELECT * FROM Livraison where idCommande = $idCommande";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function countLivrEtat($etat){
			$sql = "SELECT * FROM Livraison where etat = $etat";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function recupererEtatParIdCommande($idCommande){
			$sql = "SELECT etat FROM Livraison where idCommande = $idCommande";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				foreach($liste as $row){
					return $row['etat'];
				}
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
	}
?>
<?php


class ProduitCommandeC
{
  function afficherProduitCommande($produitCommande)
  {
    echo "Id: " . $produitCommande->getId() . "<br>";
    echo "Reference Produit: " . $produitCommande->getRefProd() . "<br>";
    echo "Id Client: " . $produitCommande->getIdClient() . "<br>";
    echo "Quantite: " . $produitCommande->getQte() . "<br>";
    echo "Id Panier: " . $produitCommande->getIdPanier() . "<br>";
    echo "Date d'Ajout: " . $produitCommande->getDate_a() . "<br>";
  }

  function ajouterProduitCommande($produitCommande)
  {
    $sql = "INSERT INTO ProduitCommande(id, refProd, idClient, qte, idPanier, date_a) values(:id, :refProd, :idClient, :qte, :idPanier, :date_a)";
    $db = config::getConnexion();
    try {
      $req = $db->prepare($sql);
      $id = $produitCommande->getId();
      $refProd = $produitCommande->getRefProd();
      $idClient = $produitCommande->getIdClient();
      $qte = $produitCommande->getQte();
      $idPanier = $produitCommande->getIdPanier();
      $date_a = $produitCommande->getDate_a();
      $req->bindValue(':id', $id);
      $req->bindValue(':refProd', $refProd);
      $req->bindValue(':idClient', $idClient);
      $req->bindValue(':qte', $qte);
      $req->bindValue(':idPanier', $idPanier);
      $req->bindValue(':date_a', $date_a);
      $req->execute();
    } catch (Exception $e) {
      echo 'Erreur: ' . $e->getMessage();
    }
  }

  function afficherProduitCommandes()
  {
    $sql = "SELECT * FROM ProduitCommande";
    $db = config::getConnexion();
    try {
      $liste = $db->query($sql);
      return $liste;
    } catch (Exception $e) {
      die('Erreur: ' . $e->getMessage());
    }
  }

  function supprimerProduitCommande($id)
  {
    $sql = "DELETE FROM ProduitCommande where id = :id";
    $db = config::getConnexion();
    $req = $db->prepare($sql);
    $req->bindValue(':id', $id);
    try {
      $req->execute();
    } catch (Exception $e) {
      die('Erreur: ' . $e->getMessage());
    }
  }

  function modifierProduitCommande($produitCommande, $id)
  {
    $sql = "UPDATE ProduitCommande SET qte = :qte WHERE id = :id";
    $db = config::getConnexion();
    try {
      $req = $db->prepare($sql);
      $qte = $client->getQte();
      $datas = array(':id' => $id, ':qte' => $qte);
      $req->bindValue(':id', $id);
      $req->bindValue(':qte', $qte);
      $s = $req->execute();
    } catch (Exception $e) {
      echo " Erreur ! " . $e->getMessage();
      echo " Les datas : ";
      print_r($datas);
    }
  }

  function recupererProduitCommande($id)
  {
    $sql = "SELECT * FROM ProduitCommande where id = $id";
    $db = config::getConnexion();
    try {
      $liste = $db->query($sql);
      return $liste;
    } catch (Exception $e) {
      die('Erreur: ' . $e->getMessage());
    }
  }
}

?>

<?php
	//include "../config.php";
	class LivreurC{
		function afficherLivreur($livreur){
			echo "Cin: ".$livreur->getCin()."<br>";
			echo "Mail: ".$livreur->getMail()."<br>";
			echo "Nom: ".$livreur->getNom()."<br>";
			echo "Prenom: ".$livreur->getPrenom()."<br>";
			echo "Date de Naissance: ".$livreur->getDateNaiss()."<br>";
		}
		function ajouterLivreur($livreur){
			$sql = "INSERT INTO Livreur(cin, mail, nom, prenom, dateNaiss) values(:cin, :mail, :nom, :prenom, :dateNaiss)";
			$db = config::getConnexion();
			try{
		       	$req = $db->prepare($sql);
		       	$cin = $livreur->getCin();
		       	$mail = $livreur->getMail();
		        $nom = $livreur->getNom();
		        $prenom = $livreur->getPrenom();
		        $dateNaiss = $livreur->getDateNaiss();
		        $req->bindValue(':cin', $cin);
		        $req->bindValue(':mail', $mail);
				$req->bindValue(':nom', $nom);
				$req->bindValue(':prenom', $prenom);
				$req->bindValue(':dateNaiss', $dateNaiss);
		        $req->execute(); 
		    }catch(Exception $e){
		        echo 'Erreur: '.$e->getMessage();
		    }
		}
		function afficherLivreurs(){
			$sql = "SELECT * FROM Livreur";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }	
		}
		function supprimerLivreur($cin){
			$sql = "DELETE FROM Livreur where cin = :cin";
			$db = config::getConnexion();
		    $req = $db->prepare($sql);
			$req->bindValue(':cin', $cin);
			try{
		        $req->execute();
		    }catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function modifierLivreur($livreur, $cin){
			$sql = "UPDATE Livreur SET cin = :cinNew, mail = :mail, nom = :nom, prenom = :prenom, dateNaiss = :dateNaiss WHERE cin = :cin";
			$db = config::getConnexion();
			try{
		        $req = $db->prepare($sql);
				$cinNew = $livreur->getCin();
				$mail = $livreur->getMail();
		        $nom = $livreur->getNom();
		        $prenom = $livreur->getPrenom();
		        $dateNaiss = $livreur->getDateNaiss();
				$datas = array(':cinNew' => $cinNew, ':mail' => $mail, ':nom'=>$nom, ':prenom'=>$prenom, ':dateNaiss' => $dateNaiss);
				$req->bindValue(':cinNew', $cinNew);
				$req->bindValue(':mail', $mail);
				$req->bindValue(':nom', $nom);
				$req->bindValue(':prenom', $prenom);
				$req->bindValue(':dateNaiss', $dateNaiss);
				$req->bindValue(':cin', $cin);
		        $s = $req->execute();
		    }catch(Exception $e){
		        echo " Erreur ! ".$e->getMessage();
		   		echo " Les datas : " ;
		  		print_r($datas);
		    }	
		}
		function recupererLivreur($cin){
			$sql = "SELECT * FROM Livreur where cin = $cin";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
	}
?>
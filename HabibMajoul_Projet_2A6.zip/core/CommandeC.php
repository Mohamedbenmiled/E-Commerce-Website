<?php
	//include "../../config.php";
	class CommandeC{
		function afficherCommande($commande){
			echo "Id: ".$commande->getId()."<br>";
			echo "Nom: ".$commande->getNom()."<br>";
		}
		function ajouterCommande($commande){
			$sql = "INSERT INTO Commande(id, prixTotal) values(:id, :prixTotal)";
			$db = config::getConnexion();
			try{
		       	$req = $db->prepare($sql);
		       	$id = $commande->getId();
		       	$prixTotal = $commande->getPrixTotal();
		        $req->bindValue(':id', $id);
		        $req->bindValue(':prixTotal', $prixTotal);
				$req->execute(); 
		    }catch(Exception $e){
		        echo 'Erreur: '.$e->getMessage();
		    }
		}
		function afficherCommandes(){
			$sql = "SELECT * FROM Commande";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }	
		}
		function supprimerCommande($id){
			$sql = "DELETE FROM Commande where id = :id";
			$db = config::getConnexion();
		    $req = $db->prepare($sql);
			$req->bindValue(':id', $id);
			try{
		        $req->execute();
		    }catch(Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function modifierCommande($commande, $id){
			$sql = "UPDATE Commande SET prixTotal = :prixTotal WHERE id = :id";
			$db = config::getConnexion();
			try{
		        $req = $db->prepare($sql);
				$idNew = $commande->getId();
				$prixTotal = $commande->getPrixTotal();
				$datas = array(':prixTotal' => $prixTotal);
				$req->bindValue('prixTotal', $prixTotal);
				$req->bindValue(':id', $id);
		        $s = $req->execute();
		    }catch(Exception $e){
		        echo " Erreur ! ".$e->getMessage();
		   		echo " Les datas : " ;
		  		print_r($datas);
		    }	
		}
		function recupererCommande($id){
			$sql = "SELECT * FROM Commande where id = $id";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}   catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
		function nbProduits($idPanier){
			$sql = "SELECT COUNT(*) FROM ProduitCommande where idPanier = $idPanier";
			$db = config::getConnexion();
			try{
				$liste = $db->query($sql);
				return $liste;
			}   catch (Exception $e){
		        die('Erreur: '.$e->getMessage());
		    }
		}
	}
?>
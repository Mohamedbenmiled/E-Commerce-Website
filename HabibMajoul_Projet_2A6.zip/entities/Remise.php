<?php
	class Remise{
		private $refProd;
		private $Id_E;
		private $taux;
		function __construct($refProd, $Id_E, $taux){
			$this->refProd = $refProd;
			$this->Id_E = $Id_E;
			$this->taux = $taux;
		}
		
		function getRefProd(){
			return $this->refProd;
		}
		function getId_E(){
			return $this->Id_E;
		}
		function getTaux(){
			return $this->taux;
		}
		function setRefProd($refProd){
			$this->refProd = $refProd;
		}
		function setId_E($Id_E){
			$this->Id_E = $Id_E;
		}
		function setTaux($taux){
			$this->taux = $taux;
		}
	}
?>
<?php
	include "../../config.php";
	include "../../entities/Avis.php";
	include "../../core/AvisC.php";
	if(isset($_POST['ref']) and isset($_POST['idClient']) and isset($_POST['appreciation'])){
		$date = date("Y/m/d H:i:s");
		if($_POST['rate'] == NULL){
			$note = 0;
		}else{
			$note = $_POST['rate'];
		}
	    $Avis1 = new Avis($_POST['ref'], $_POST['idClient'], $note, $_POST['appreciation'], $date);
		$Avis1C = new AvisC();
		$Avis1C->ajouterAvis($Avis1);
		include "../../entities/Produit.php";
		include "../../core/ProduitC.php";
		$avis = $Avis1C->recupereravis($_POST['ref']);
		$total = $avis->rowCount();
		$noteMoy = 0;
		foreach($avis as $row){
			$noteMoy += $row['note'];
		}
		$noteMoy /= $total;
		$produitC = new ProduitC();
		$produitC->updateNoteMoy($noteMoy, $_POST['ref']);
		$ref = $_POST['ref'];
		header("Location: ../item.php?ref=$ref");	
	}
	else{
		echo "Verifier les champs";
	}
?>


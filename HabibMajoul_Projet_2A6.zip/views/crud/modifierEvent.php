<html>
	<head>
	</head>

	<body>
		<?php
			include "../entities/Event.php";
			include "../core/EventC.php";
			if(isset($_GET['id'])){
				$EventC = new EventC();
			    $result = $EventC->recupererEvent($_GET['id']);
				foreach($result as $row){
					$id = $row['id'];
					$nom = $row['nom'];
					$date_dbt = $row['date_debut'];
					$date_fin = $row['date_fin'];
		?>
		<form method="POST">
			<table>
				<caption>Modifier Evenement</caption>
				<tr>
					<td>Id</td>
					<td><input type="number" name="id" value="<?php echo $id ?>"></td>
				</tr>
				<tr>
					<td>Nom</td>
					<td><input type="text" name="nom" value="<?php echo $nom ?>"></td>
				</tr>
				<tr>
					<td>Debut de l'evenement</td>
					<td><input type="date" name="date_dbt" value="<?php echo $date_dbt ?>"></td>
				</tr>
				<tr>
					<td>Fin de l'evenement</td>
					<td><input type="date" name="date_fin" value="<?php echo $date_fin ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="modifier" value="Modifier"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="hidden" name="id_ini" value="<?php echo $_GET['id'];?>"></td>
				</tr>
			</table>
		</form>
		<?PHP
				}
			}
			if(isset($_POST['modifier'])){
				$Event = new Event($_POST['id'], $_POST['nom'], $_POST['date_dbt'], $_POST['date_fin']);
				$EventC->modifierEvent($Event, $_POST['id_ini']);
				echo $_POST['id_ini'];
				header('Location: afficherEvent.php');
			}
		?>
	</body>
</html>
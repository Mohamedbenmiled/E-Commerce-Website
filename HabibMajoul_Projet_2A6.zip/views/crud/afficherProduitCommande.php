<?PHP
    include "../core/ProduitCommandeC.php";
    $produitCommande1C = new ProduitCommandeC();
    $listeProduitCommandes = $produitCommande1C->afficherProduitCommandes();
?>

<table border="1">
    <tr>
        <td>Id</td>
        <td>Reference Produit</td>
        <td>Id Client</td>
        <td>Quantite</td>
        <td>Id Panier</td>
        <td>Date d'Ajout</td>
        <td>Supprimer</td>
        <td>Modifier</td>
    </tr>
    <?php
    	foreach($listeProduitCommandes as $row){
    ?>
    <tr>
        <td><?php echo $row['id']; ?></td>
        <td><?php echo $row['refProd']; ?></td>
        <td><?php echo $row['idClient']; ?></td>
        <td><?php echo $row['qte']; ?></td>
        <td><?php echo $row['idPanier']; ?></td>
        <td><?php echo $row['date_a']; ?></td>
        <td>
        	<form method="POST" action="supprimerProduitCommande.php">
	            <input type="submit" name="supprimer" value="Supprimer">
	            <input type="hidden" value="<?php echo $row['id']; ?>" name="id">
            </form>
        </td>
        <td>
        	<a href="modifierProduitCommande.php?id=<?php echo $row['id']; ?>">
            Modifier</a></td>
    </tr>
    <?php
    	}
    ?>
</table>
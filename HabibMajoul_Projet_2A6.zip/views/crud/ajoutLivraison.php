<?php
	include "../entities/Livraison.php";
	include "../core/LivraisonC.php";
	if(isset($_POST['idCommande']) and isset($_POST['cinLivreur']) and isset($_POST['etat']) and isset($_POST['dateLivraison'])){
	$livraison1 = new Livraison($_POST['idCommande'], $_POST['cinLivreur'], $_POST['etat'], $_POST['dateLivraison']);
		$livraison1C = new LivraisonC();
		$livraison1C->ajouterLivraison($livraison1);
		header('Location: afficherLivraison.php');	
	}else{
		echo "Verifier les champs";
	}
?>
<?php
//include "../config.php";

class SponsorC
{
    function afficherSponsor($sponsor)
    {

        echo "Nom: " . $sponsor->getNom() . "<br>";
        echo "Adresse: " . $sponsor->getAdresse() . "<br>";
        echo "Type: " . $sponsor->getType() . "<br>";
        echo "Budget: " . $sponsor->getBudget() . "<br>";

    }

    function ajouterSponsor($sponsor)
    {
        $sql = "INSERT INTO Sponsor(  nom,  adresse, type, budget) values( :nom, :adresse, :type ,:budget)";
        $db = config::getConnexion();
        try {
            $req = $db->prepare($sql);

            $nom = $sponsor->getNom();
            $adresse = $sponsor->getAdresse();
            $type = $sponsor->getType();
            $budget=$sponsor->getBudget();

            $req->bindValue(':nom', $nom);
            $req->bindValue(':adresse', $adresse);
            $req->bindValue(':type', $type);
            $req->bindValue(':budget', $budget);
            $req->execute();
        } catch (Exception $e) {
            echo 'Erreur: ' . $e->getMessage();
        }
    }

    function affichersSponsor()
    {
        $sql = "SELECT * FROM Sponsor";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }

    function afficherSponsorOrdered()
    {
        $sql = "SELECT * FROM Sponsor ORDER BY budget desc";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }

    function supprimerSponsor($id)
    {
        $sql = "DELETE FROM Sponsor where id = :id";
        $db = config::getConnexion();
        $req = $db->prepare($sql);
        $req->bindValue(':id', $id);
        try {
            $req->execute();
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }

    function modifierSponsor($sponsor, $id)
    {
        $sql = "UPDATE Sponsor SET  nom = :nom, adresse = :adresse, type = :type , budget= :budget WHERE id = :id";
        $db = config::getConnexion();
        try {
            $req = $db->prepare($sql);

            $nom = $sponsor->getNom();
            $adresse = $sponsor->getAdresse();
            $type = $sponsor->getType();
            $budget = $sponsor->getBudget();
            $datas = array( ':nom' => $nom,  ':adresse' => $adresse, ':type' => $type, ':budget' => $budget);

            $req->bindValue(':nom', $nom);
            $req->bindValue(':adresse', $adresse);
            $req->bindValue(':type', $type);
            $req->bindValue(':budget', $budget);
            $req->bindValue(':id', $id);
            $s = $req->execute();
        } catch (Exception $e) {
            echo " Erreur ! " . $e->getMessage();
            echo " Les datas : ";
            print_r($datas);
        }
    }

    function recupererSponsor($id)
    {
        $sql = "SELECT * FROM Sponsor where id = $id";
        $db = config::getConnexion();
        try {
            $liste = $db->query($sql);
            return $liste;
        } catch (Exception $e) {
            die('Erreur: ' . $e->getMessage());
        }
    }
}

?>

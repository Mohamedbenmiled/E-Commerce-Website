<?php
	class Commande{
		private $id;
		private $prixTotal;
		function __construct($id, $prixTotal){
			$this->id = $id;
			$this->prixTotal = $prixTotal;
		}
		function getId(){
			return $this->id;
		}
		function getPrixTotal(){
			return $this->prixTotal;
		}
	}
?>
<?php
	class Event{
		private $Id_E;
		private $nom;
		private $date_dbt;
		private $date_fin;
		function __construct($Id_E, $nom, $date_dbt, $date_fin){
			$this->Id_E = $Id_E;
			$this->nom = $nom;
			$this->date_dbt = $date_dbt;
			$this->date_fin = $date_fin;
		}
		function getId_E(){
			return $this->Id_E;
		}
		function getNom(){
			return $this->nom;
		}
		function getDate_dbt(){
			return $this->date_dbt;
		}
		function getDate_fin(){
			return $this->date_fin;
		}
		function setId_E($Id_E){
			$this->Id_E = $Id_E;
		}
		function setNom($nom){
			$this->nom = $nom;
		}
		function setDate_dbt($date_dbt){
			$this->date_dbt = $date_dbt;
		}
		function setDate_fin($date_fin){
			$this->date_fin = $date_fin;
		}
	}
?>